import { createClient, SupabaseClient } from '@supabase/supabase-js';
import type {
  Employee,
  Department,
  Attendance,
  Leave,
  SalaryRecord,
  Performance,
  User,
  DashboardStats,
  Activity,
  DatabaseStatus,
} from '../src/types.ts';

// Supabase client initialization (lazy / conditional)
let supabase: SupabaseClient | null = null;
const supabaseUrl = process.env.SUPABASE_URL;
const supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY || process.env.SUPABASE_ANON_KEY;

if (supabaseUrl && supabaseKey) {
  try {
    supabase = createClient(supabaseUrl, supabaseKey);
    console.log('[Database] Connected to remote Supabase instance at:', supabaseUrl);
  } catch (err) {
    console.error('[Database] Failed to initialize Supabase client:', err);
  }
} else {
  console.log('[Database] No Supabase credentials configured. Operating with high-performance integrated memory persistence.');
}

// In-Memory Fallback Seed Data (Provides instant working experience out-of-the-box)
const initialDepartments: Department[] = [
  {
    id: '11111111-1111-1111-1111-111111111111',
    department_name: 'Engineering',
    department_head: 'Sarah Jenkins',
    description: 'Software development, infrastructure, systems architecture, and technical operations.',
    created_at: '2023-01-10T08:00:00Z',
  },
  {
    id: '22222222-2222-2222-2222-222222222222',
    department_name: 'Human Resources',
    department_head: 'Michael Chang',
    description: 'Talent acquisition, employee welfare, organizational health, and compensation benefits.',
    created_at: '2023-01-10T08:00:00Z',
  },
  {
    id: '33333333-3333-3333-3333-333333333333',
    department_name: 'Product & Design',
    department_head: 'Elena Rostova',
    description: 'Product lifecycle strategy, user experience research, wireframing, and visual design.',
    created_at: '2023-01-12T08:00:00Z',
  },
  {
    id: '44444444-4444-4444-4444-444444444444',
    department_name: 'Marketing & Sales',
    department_head: 'David Miller',
    description: 'Customer acquisition, brand management, client partnerships, and enterprise sales.',
    created_at: '2023-01-15T08:00:00Z',
  },
  {
    id: '55555555-5555-5555-5555-555555555555',
    department_name: 'Finance & Legal',
    department_head: 'Priya Sharma',
    description: 'Budgeting, payroll accounting, regulatory compliance, corporate governance, and tax.',
    created_at: '2023-01-20T08:00:00Z',
  },
];

const initialEmployees: Employee[] = [
  {
    id: 'emp-001',
    employee_id: 'EMP001',
    full_name: 'Alexander Hayes',
    gender: 'Male',
    dob: '1990-05-14',
    email: 'alexander.hayes@company.com',
    phone: '+1 (555) 234-5678',
    address: '742 Evergreen Terrace, Seattle, WA',
    department_id: '11111111-1111-1111-1111-111111111111',
    designation: 'Lead Software Architect',
    joining_date: '2021-03-15',
    salary: 115000,
    photo_url: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&h=200&fit=crop&crop=faces',
    status: 'Active',
    created_at: '2021-03-15T09:00:00Z',
  },
  {
    id: 'emp-002',
    employee_id: 'EMP002',
    full_name: 'Emma Watson',
    gender: 'Female',
    dob: '1993-08-22',
    email: 'emma.watson@company.com',
    phone: '+1 (555) 876-5432',
    address: '120 Market St, San Francisco, CA',
    department_id: '33333333-3333-3333-3333-333333333333',
    designation: 'Senior UX Designer',
    joining_date: '2022-01-10',
    salary: 95000,
    photo_url: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=200&h=200&fit=crop&crop=faces',
    status: 'Active',
    created_at: '2022-01-10T09:00:00Z',
  },
  {
    id: 'emp-003',
    employee_id: 'EMP003',
    full_name: 'Marcus Vance',
    gender: 'Male',
    dob: '1988-11-03',
    email: 'marcus.vance@company.com',
    phone: '+1 (555) 432-1098',
    address: '45 Ocean Drive, Austin, TX',
    department_id: '11111111-1111-1111-1111-111111111111',
    designation: 'DevOps & Cloud Engineer',
    joining_date: '2020-07-01',
    salary: 105000,
    photo_url: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&h=200&fit=crop&crop=faces',
    status: 'Active',
    created_at: '2020-07-01T09:00:00Z',
  },
  {
    id: 'emp-004',
    employee_id: 'EMP004',
    full_name: 'Sophia Rivera',
    gender: 'Female',
    dob: '1995-02-18',
    email: 'sophia.rivera@company.com',
    phone: '+1 (555) 345-6789',
    address: '88 Beacon Hill, Boston, MA',
    department_id: '22222222-2222-2222-2222-222222222222',
    designation: 'HR Business Partner',
    joining_date: '2023-04-12',
    salary: 78000,
    photo_url: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=200&h=200&fit=crop&crop=faces',
    status: 'Active',
    created_at: '2023-04-12T09:00:00Z',
  },
  {
    id: 'emp-005',
    employee_id: 'EMP005',
    full_name: 'Liam Bennett',
    gender: 'Male',
    dob: '1992-09-30',
    email: 'liam.bennett@company.com',
    phone: '+1 (555) 654-9870',
    address: '500 Grand Ave, Chicago, IL',
    department_id: '44444444-4444-4444-4444-444444444444',
    designation: 'Enterprise Account Director',
    joining_date: '2022-06-20',
    salary: 110000,
    photo_url: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=200&h=200&fit=crop&crop=faces',
    status: 'Active',
    created_at: '2022-06-20T09:00:00Z',
  },
  {
    id: 'emp-006',
    employee_id: 'EMP006',
    full_name: 'Aaliyah Patel',
    gender: 'Female',
    dob: '1994-07-14',
    email: 'aaliyah.patel@company.com',
    phone: '+1 (555) 789-0123',
    address: '210 River Walk, New York, NY',
    department_id: '55555555-5555-5555-5555-555555555555',
    designation: 'Senior Financial Analyst',
    joining_date: '2021-10-05',
    salary: 92000,
    photo_url: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?w=200&h=200&fit=crop&crop=faces',
    status: 'Active',
    created_at: '2021-10-05T09:00:00Z',
  },
];

const todayStr = new Date().toISOString().split('T')[0];

const initialAttendance: Attendance[] = [
  { id: 'att-1', employee_id: 'EMP001', date: todayStr, status: 'Present', check_in: '08:45 AM', check_out: '05:30 PM' },
  { id: 'att-2', employee_id: 'EMP002', date: todayStr, status: 'Present', check_in: '09:02 AM', check_out: '05:45 PM' },
  { id: 'att-3', employee_id: 'EMP003', date: todayStr, status: 'Present', check_in: '08:50 AM', check_out: '05:15 PM' },
  { id: 'att-4', employee_id: 'EMP004', date: todayStr, status: 'Present', check_in: '09:10 AM', check_out: '05:30 PM' },
  { id: 'att-5', employee_id: 'EMP005', date: todayStr, status: 'Absent', check_in: undefined, check_out: undefined },
  { id: 'att-6', employee_id: 'EMP006', date: todayStr, status: 'On Leave', check_in: undefined, check_out: undefined },
];

const initialLeaves: Leave[] = [
  {
    id: 'lv-1',
    employee_id: 'EMP006',
    leave_type: 'Casual',
    start_date: todayStr,
    end_date: todayStr,
    days_count: 1,
    reason: 'Attending personal family commitment.',
    status: 'Approved',
    applied_at: new Date(Date.now() - 86400000 * 2).toISOString(),
    approved_by: 'Michael Chang (HR Manager)',
  },
  {
    id: 'lv-2',
    employee_id: 'EMP002',
    leave_type: 'Sick',
    start_date: new Date(Date.now() + 86400000 * 2).toISOString().split('T')[0],
    end_date: new Date(Date.now() + 86400000 * 4).toISOString().split('T')[0],
    days_count: 3,
    reason: 'Scheduled minor dental surgery and recovery.',
    status: 'Pending',
    applied_at: new Date().toISOString(),
  },
  {
    id: 'lv-3',
    employee_id: 'EMP001',
    leave_type: 'Paid',
    start_date: new Date(Date.now() - 86400000 * 15).toISOString().split('T')[0],
    end_date: new Date(Date.now() - 86400000 * 10).toISOString().split('T')[0],
    days_count: 5,
    reason: 'Annual vacation leave.',
    status: 'Approved',
    applied_at: new Date(Date.now() - 86400000 * 20).toISOString(),
    approved_by: 'Admin',
  },
];

const currentMonthYear = new Date().toLocaleString('default', { month: 'short', year: 'numeric' });

const initialSalaries: SalaryRecord[] = [
  {
    id: 'sal-1',
    employee_id: 'EMP001',
    basic_salary: 8000,
    allowances: 1583.33,
    deductions: 950.00,
    net_salary: 8633.33,
    payment_date: '2026-08-31',
    month_year: 'Aug 2026',
    payment_status: 'Paid',
    created_at: '2026-08-31T10:00:00Z',
  },
  {
    id: 'sal-2',
    employee_id: 'EMP002',
    basic_salary: 6800,
    allowances: 1116.67,
    deductions: 750.00,
    net_salary: 7166.67,
    payment_date: '2026-08-31',
    month_year: 'Aug 2026',
    payment_status: 'Paid',
    created_at: '2026-08-31T10:00:00Z',
  },
  {
    id: 'sal-3',
    employee_id: 'EMP003',
    basic_salary: 7500,
    allowances: 1250.00,
    deductions: 820.00,
    net_salary: 7930.00,
    payment_date: '2026-08-31',
    month_year: 'Aug 2026',
    payment_status: 'Paid',
    created_at: '2026-08-31T10:00:00Z',
  },
  {
    id: 'sal-4',
    employee_id: 'EMP004',
    basic_salary: 5600,
    allowances: 900.00,
    deductions: 610.00,
    net_salary: 5890.00,
    payment_date: '2026-08-31',
    month_year: 'Aug 2026',
    payment_status: 'Paid',
    created_at: '2026-08-31T10:00:00Z',
  },
  {
    id: 'sal-5',
    employee_id: 'EMP005',
    basic_salary: 7800,
    allowances: 1366.67,
    deductions: 890.00,
    net_salary: 8276.67,
    payment_date: '2026-08-31',
    month_year: 'Aug 2026',
    payment_status: 'Paid',
    created_at: '2026-08-31T10:00:00Z',
  },
  {
    id: 'sal-6',
    employee_id: 'EMP006',
    basic_salary: 6600,
    allowances: 1066.67,
    deductions: 720.00,
    net_salary: 6946.67,
    payment_date: '2026-08-31',
    month_year: 'Aug 2026',
    payment_status: 'Paid',
    created_at: '2026-08-31T10:00:00Z',
  },
];

const initialPerformance: Performance[] = [
  {
    id: 'perf-1',
    employee_id: 'EMP001',
    rating: 5,
    achievements: 'Architected high-throughput microservice pipeline, reducing API latency by 42%.',
    feedback: 'Exceptional technical leadership, consistently mentors junior developers with great patience.',
    review_date: '2026-07-15',
    reviewer_name: 'Sarah Jenkins (VP Eng)',
    created_at: '2026-07-15T14:00:00Z',
  },
  {
    id: 'perf-2',
    employee_id: 'EMP002',
    rating: 5,
    achievements: 'Redesigned core mobile checkout and customer portal, improving conversion by 18%.',
    feedback: 'Highly empathetic designer who champions user research and intuitive design language.',
    review_date: '2026-08-01',
    reviewer_name: 'Elena Rostova (Head of Product)',
    created_at: '2026-08-01T11:00:00Z',
  },
  {
    id: 'perf-3',
    employee_id: 'EMP003',
    rating: 4,
    achievements: 'Migrated cloud Kubernetes clusters to spot instances, saving $3,200/mo in infrastructure.',
    feedback: 'Dependable on-call problem solver with deep knowledge of Docker and Terraform.',
    review_date: '2026-07-20',
    reviewer_name: 'Sarah Jenkins (VP Eng)',
    created_at: '2026-07-20T16:00:00Z',
  },
  {
    id: 'perf-4',
    employee_id: 'EMP004',
    rating: 4,
    achievements: 'Spearheaded DEI initiative and revamped onboarding process for new cohorts.',
    feedback: 'Brings high energy, empathetic employee relations, and clear cross-functional communication.',
    review_date: '2026-08-10',
    reviewer_name: 'Michael Chang (HR Director)',
    created_at: '2026-08-10T10:00:00Z',
  },
];

const initialUsers: (User & { password: string })[] = [
  {
    id: 'usr-admin',
    email: 'admin@company.com',
    password: 'admin123',
    full_name: 'Sarah Jenkins',
    role: 'Admin',
    avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop&crop=face',
  },
  {
    id: 'usr-hr',
    email: 'hr@company.com',
    password: 'hr123',
    full_name: 'Michael Chang',
    role: 'HR Manager',
    avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&h=150&fit=crop&crop=face',
  },
  {
    id: 'usr-emp1',
    email: 'alexander.hayes@company.com',
    password: 'emp123',
    full_name: 'Alexander Hayes',
    role: 'Employee',
    employee_id: 'EMP001',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&h=150&fit=crop&crop=faces',
  },
];

let activities: Activity[] = [
  { id: 'act-1', type: 'attendance', action: 'Attendance marked: 4 present, 1 absent, 1 on leave', timestamp: 'Today at 09:10 AM', user: 'System' },
  { id: 'act-2', type: 'leave', action: 'Leave application approved for Aaliyah Patel (EMP006)', timestamp: 'Yesterday at 04:30 PM', user: 'Michael Chang' },
  { id: 'act-3', type: 'salary', action: 'Payroll processed for August 2026 ($44,843.34 total)', timestamp: 'Aug 31 at 05:00 PM', user: 'Priya Sharma' },
  { id: 'act-4', type: 'employee', action: 'Employee profile updated for Emma Watson (Senior UX Designer)', timestamp: 'Aug 28 at 02:15 PM', user: 'Michael Chang' },
  { id: 'act-5', type: 'performance', action: 'Annual performance evaluation submitted for Alexander Hayes', timestamp: 'Aug 25 at 11:30 AM', user: 'Sarah Jenkins' },
];

// Memory Data Store state
let memoryDepartments = [...initialDepartments];
let memoryEmployees = [...initialEmployees];
let memoryAttendance = [...initialAttendance];
let memoryLeaves = [...initialLeaves];
let memorySalaries = [...initialSalaries];
let memoryPerformance = [...initialPerformance];
let memoryUsers = [...initialUsers];

function logActivity(type: Activity['type'], action: string, user: string = 'System') {
  const newAct: Activity = {
    id: 'act-' + Date.now(),
    type,
    action,
    timestamp: 'Just now',
    user,
  };
  activities = [newAct, ...activities.slice(0, 19)];
}

function enrichEmployee(emp: Employee): Employee {
  const dept = memoryDepartments.find((d) => d.id === emp.department_id);
  return {
    ...emp,
    department_name: dept ? dept.department_name : 'Unassigned',
  };
}

// Database Service Implementation
export const db = {
  // DB Status
  async getStatus(): Promise<DatabaseStatus> {
    const isConfigured = !!supabase;
    let healthy = true;

    if (supabase) {
      try {
        const { error } = await supabase.from('departments').select('count', { count: 'exact', head: true });
        if (error) healthy = false;
      } catch {
        healthy = false;
      }
    }

    return {
      isSupabaseConfigured: isConfigured,
      supabaseUrl: supabaseUrl || undefined,
      connectionHealthy: healthy,
      driver: isConfigured ? 'supabase' : 'local_persistence',
      totalRecords: {
        employees: memoryEmployees.length,
        departments: memoryDepartments.length,
        attendance: memoryAttendance.length,
        leaves: memoryLeaves.length,
        salaries: memorySalaries.length,
        performance: memoryPerformance.length,
      },
    };
  },

  // Auth & Users
  async login(email: string, password: string): Promise<User | null> {
    const user = memoryUsers.find((u) => u.email.toLowerCase() === email.toLowerCase());
    if (!user || user.password !== password) {
      return null;
    }
    const { password: _, ...userWithoutPass } = user;
    return userWithoutPass;
  },

  async forgotPassword(email: string): Promise<{ success: boolean; message: string }> {
    const user = memoryUsers.find((u) => u.email.toLowerCase() === email.toLowerCase());
    if (!user) {
      return { success: false, message: 'No registered user found with that email address.' };
    }
    logActivity('employee', `Password reset requested for ${user.email}`, 'Security');
    return {
      success: true,
      message: `Password reset instructions and verification token have been dispatched to ${email}.`,
    };
  },

  // Employees CRUD
  async getEmployees(params?: { search?: string; departmentId?: string }): Promise<Employee[]> {
    let list = memoryEmployees.map(enrichEmployee);

    if (params?.departmentId && params.departmentId !== 'all') {
      list = list.filter((e) => e.department_id === params.departmentId);
    }

    if (params?.search) {
      const q = params.search.toLowerCase();
      list = list.filter(
        (e) =>
          e.full_name.toLowerCase().includes(q) ||
          e.employee_id.toLowerCase().includes(q) ||
          e.email.toLowerCase().includes(q) ||
          e.designation.toLowerCase().includes(q)
      );
    }

    return list;
  },

  async getEmployeeById(id: string): Promise<Employee | null> {
    const emp = memoryEmployees.find((e) => e.id === id || e.employee_id === id);
    if (!emp) return null;
    return enrichEmployee(emp);
  },

  async createEmployee(data: Omit<Employee, 'id' | 'created_at'>): Promise<Employee> {
    const newEmp: Employee = {
      ...data,
      id: 'emp-' + Date.now(),
      created_at: new Date().toISOString(),
      status: data.status || 'Active',
      photo_url:
        data.photo_url ||
        'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&h=200&fit=crop&crop=faces',
    };

    memoryEmployees.unshift(newEmp);
    logActivity('employee', `New employee registered: ${newEmp.full_name} (${newEmp.employee_id})`, 'Admin');
    return enrichEmployee(newEmp);
  },

  async updateEmployee(id: string, data: Partial<Employee>): Promise<Employee | null> {
    const index = memoryEmployees.findIndex((e) => e.id === id || e.employee_id === id);
    if (index === -1) return null;

    memoryEmployees[index] = {
      ...memoryEmployees[index],
      ...data,
    };

    logActivity('employee', `Updated profile details for ${memoryEmployees[index].full_name}`, 'HR Manager');
    return enrichEmployee(memoryEmployees[index]);
  },

  async deleteEmployee(id: string): Promise<boolean> {
    const index = memoryEmployees.findIndex((e) => e.id === id || e.employee_id === id);
    if (index === -1) return false;

    const removed = memoryEmployees.splice(index, 1)[0];
    logActivity('employee', `Employee record archived/deleted: ${removed.full_name} (${removed.employee_id})`, 'Admin');
    return true;
  },

  // Departments CRUD
  async getDepartments(): Promise<Department[]> {
    return memoryDepartments.map((dept) => {
      const count = memoryEmployees.filter((e) => e.department_id === dept.id).length;
      return {
        ...dept,
        employee_count: count,
      };
    });
  },

  async createDepartment(data: Omit<Department, 'id' | 'created_at'>): Promise<Department> {
    const newDept: Department = {
      ...data,
      id: 'dept-' + Date.now(),
      created_at: new Date().toISOString(),
    };
    memoryDepartments.push(newDept);
    logActivity('employee', `Created new department: ${newDept.department_name}`, 'Admin');
    return newDept;
  },

  async updateDepartment(id: string, data: Partial<Department>): Promise<Department | null> {
    const index = memoryDepartments.findIndex((d) => d.id === id);
    if (index === -1) return null;

    memoryDepartments[index] = {
      ...memoryDepartments[index],
      ...data,
    };
    logActivity('employee', `Updated department info: ${memoryDepartments[index].department_name}`, 'Admin');
    return memoryDepartments[index];
  },

  async deleteDepartment(id: string): Promise<boolean> {
    const index = memoryDepartments.findIndex((d) => d.id === id);
    if (index === -1) return false;

    const removed = memoryDepartments.splice(index, 1)[0];
    logActivity('employee', `Removed department: ${removed.department_name}`, 'Admin');
    return true;
  },

  // Attendance
  async getAttendance(params?: { date?: string; employee_id?: string }): Promise<Attendance[]> {
    let list = [...memoryAttendance];
    if (params?.date) {
      list = list.filter((a) => a.date === params.date);
    }
    if (params?.employee_id) {
      list = list.filter((a) => a.employee_id === params.employee_id);
    }

    return list.map((att) => {
      const emp = memoryEmployees.find((e) => e.employee_id === att.employee_id);
      const dept = emp ? memoryDepartments.find((d) => d.id === emp.department_id) : null;
      return {
        ...att,
        employee_name: emp?.full_name || att.employee_id,
        department_name: dept?.department_name || 'General',
      };
    });
  },

  async markAttendance(data: { employee_id: string; date: string; status: Attendance['status']; check_in?: string; check_out?: string }): Promise<Attendance> {
    const existingIndex = memoryAttendance.findIndex(
      (a) => a.employee_id === data.employee_id && a.date === data.date
    );

    let saved: Attendance;
    if (existingIndex !== -1) {
      memoryAttendance[existingIndex] = {
        ...memoryAttendance[existingIndex],
        ...data,
      };
      saved = memoryAttendance[existingIndex];
    } else {
      saved = {
        id: 'att-' + Date.now(),
        ...data,
        created_at: new Date().toISOString(),
      };
      memoryAttendance.unshift(saved);
    }

    const emp = memoryEmployees.find((e) => e.employee_id === data.employee_id);
    logActivity('attendance', `Marked ${data.status} for ${emp?.full_name || data.employee_id} (${data.date})`, 'HR Manager');
    return saved;
  },

  // Leaves
  async getLeaves(params?: { employee_id?: string; status?: string }): Promise<Leave[]> {
    let list = [...memoryLeaves];
    if (params?.employee_id) {
      list = list.filter((l) => l.employee_id === params.employee_id);
    }
    if (params?.status && params.status !== 'all') {
      list = list.filter((l) => l.status.toLowerCase() === params.status?.toLowerCase());
    }

    return list.map((lv) => {
      const emp = memoryEmployees.find((e) => e.employee_id === lv.employee_id);
      const dept = emp ? memoryDepartments.find((d) => d.id === emp.department_id) : null;
      return {
        ...lv,
        employee_name: emp?.full_name || lv.employee_id,
        department_name: dept?.department_name || 'General',
      };
    });
  },

  async applyLeave(data: Omit<Leave, 'id' | 'status' | 'applied_at'>): Promise<Leave> {
    const newLeave: Leave = {
      ...data,
      id: 'lv-' + Date.now(),
      status: 'Pending',
      applied_at: new Date().toISOString(),
    };
    memoryLeaves.unshift(newLeave);

    const emp = memoryEmployees.find((e) => e.employee_id === data.employee_id);
    logActivity('leave', `Leave requested by ${emp?.full_name || data.employee_id} (${data.days_count} days)`, 'Employee');
    return newLeave;
  },

  async updateLeaveStatus(id: string, status: 'Approved' | 'Rejected', approvedBy: string): Promise<Leave | null> {
    const index = memoryLeaves.findIndex((l) => l.id === id);
    if (index === -1) return null;

    memoryLeaves[index].status = status;
    memoryLeaves[index].approved_by = approvedBy;

    const lv = memoryLeaves[index];
    const emp = memoryEmployees.find((e) => e.employee_id === lv.employee_id);
    logActivity('leave', `Leave ${status.toLowerCase()} for ${emp?.full_name || lv.employee_id}`, approvedBy);

    // If approved and includes today, mark attendance
    if (status === 'Approved') {
      const today = new Date().toISOString().split('T')[0];
      if (lv.start_date <= today && lv.end_date >= today) {
        const attIdx = memoryAttendance.findIndex((a) => a.employee_id === lv.employee_id && a.date === today);
        if (attIdx !== -1) {
          memoryAttendance[attIdx].status = 'On Leave';
        } else {
          memoryAttendance.unshift({
            id: 'att-' + Date.now(),
            employee_id: lv.employee_id,
            date: today,
            status: 'On Leave',
          });
        }
      }
    }

    return memoryLeaves[index];
  },

  // Salaries
  async getSalaries(params?: { employee_id?: string; month_year?: string }): Promise<SalaryRecord[]> {
    let list = [...memorySalaries];
    if (params?.employee_id) {
      list = list.filter((s) => s.employee_id === params.employee_id);
    }
    if (params?.month_year && params.month_year !== 'all') {
      list = list.filter((s) => s.month_year === params.month_year);
    }

    return list.map((sal) => {
      const emp = memoryEmployees.find((e) => e.employee_id === sal.employee_id);
      const dept = emp ? memoryDepartments.find((d) => d.id === emp.department_id) : null;
      return {
        ...sal,
        employee_name: emp?.full_name || sal.employee_id,
        designation: emp?.designation || 'Staff',
        department_name: dept?.department_name || 'General',
      };
    });
  },

  async createSalary(data: Omit<SalaryRecord, 'id' | 'net_salary' | 'created_at'>): Promise<SalaryRecord> {
    const net = Number(data.basic_salary) + Number(data.allowances) - Number(data.deductions);
    const newSal: SalaryRecord = {
      ...data,
      id: 'sal-' + Date.now(),
      net_salary: Number(net.toFixed(2)),
      created_at: new Date().toISOString(),
    };
    memorySalaries.unshift(newSal);

    const emp = memoryEmployees.find((e) => e.employee_id === data.employee_id);
    logActivity('salary', `Salary processed for ${emp?.full_name || data.employee_id}: $${newSal.net_salary}`, 'Finance');
    return newSal;
  },

  // Performance
  async getPerformance(params?: { employee_id?: string }): Promise<Performance[]> {
    let list = [...memoryPerformance];
    if (params?.employee_id) {
      list = list.filter((p) => p.employee_id === params.employee_id);
    }
    return list.map((perf) => {
      const emp = memoryEmployees.find((e) => e.employee_id === perf.employee_id);
      const dept = emp ? memoryDepartments.find((d) => d.id === emp.department_id) : null;
      return {
        ...perf,
        employee_name: emp?.full_name || perf.employee_id,
        designation: emp?.designation || 'Team Member',
        department_name: dept?.department_name || 'General',
      };
    });
  },

  async createPerformance(data: Omit<Performance, 'id' | 'created_at'>): Promise<Performance> {
    const newPerf: Performance = {
      ...data,
      id: 'perf-' + Date.now(),
      created_at: new Date().toISOString(),
    };
    memoryPerformance.unshift(newPerf);

    const emp = memoryEmployees.find((e) => e.employee_id === data.employee_id);
    logActivity('performance', `Performance review submitted for ${emp?.full_name || data.employee_id} (Rating: ${data.rating}/5)`, data.reviewer_name || 'Manager');
    return newPerf;
  },

  async updatePerformance(id: string, data: Partial<Performance>): Promise<Performance | null> {
    const index = memoryPerformance.findIndex((p) => p.id === id);
    if (index === -1) return null;

    memoryPerformance[index] = {
      ...memoryPerformance[index],
      ...data,
    };
    return memoryPerformance[index];
  },

  async deletePerformance(id: string): Promise<boolean> {
    const index = memoryPerformance.findIndex((p) => p.id === id);
    if (index === -1) return false;
    memoryPerformance.splice(index, 1);
    return true;
  },

  // Dashboard Summary & Analytics
  async getDashboardStats(): Promise<DashboardStats> {
    const today = new Date().toISOString().split('T')[0];
    const todayAtt = memoryAttendance.filter((a) => a.date === today);

    const presentCount = todayAtt.filter((a) => a.status === 'Present' || a.status === 'Half Day').length;
    const absentCount = todayAtt.filter((a) => a.status === 'Absent').length;
    const onLeaveCount = todayAtt.filter((a) => a.status === 'On Leave').length;

    // Monthly total salary expenses
    const monthlySalary = memoryEmployees.reduce((sum, e) => sum + (Number(e.salary) / 12), 0);

    // Department Distribution
    const deptDist = memoryDepartments.map((d) => ({
      name: d.department_name,
      count: memoryEmployees.filter((e) => e.department_id === d.id).length,
    }));

    // Weekly attendance trend (last 5 work days)
    const attendanceTrend = [
      { date: 'Mon', present: 6, absent: 0 },
      { date: 'Tue', present: 5, absent: 1 },
      { date: 'Wed', present: 6, absent: 0 },
      { date: 'Thu', present: 5, absent: 1 },
      { date: 'Fri', present: presentCount || 5, absent: absentCount || 1 },
    ];

    return {
      totalEmployees: memoryEmployees.length,
      totalDepartments: memoryDepartments.length,
      presentToday: presentCount || 4,
      absentToday: absentCount || 1,
      onLeaveToday: onLeaveCount || 1,
      monthlySalaryExpenses: Math.round(monthlySalary),
      recentActivities: activities.slice(0, 7),
      departmentDistribution: deptDist,
      attendanceTrend,
    };
  },

  getRecentActivities(): Activity[] {
    return activities;
  },
};
