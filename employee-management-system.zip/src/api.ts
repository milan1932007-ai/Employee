import type {
  Employee,
  Department,
  Attendance,
  Leave,
  SalaryRecord,
  Performance,
  User,
  DashboardStats,
  DatabaseStatus,
} from './types.ts';

const BASE_URL = '/api';

async function request<T>(endpoint: string, options?: RequestInit): Promise<T> {
  const res = await fetch(`${BASE_URL}${endpoint}`, {
    headers: {
      'Content-Type': 'application/json',
      ...options?.headers,
    },
    ...options,
  });

  if (!res.ok) {
    let errMsg = `Request failed with status ${res.status}`;
    try {
      const data = await res.json();
      if (data.error) errMsg = data.error;
    } catch {
      // ignore
    }
    throw new Error(errMsg);
  }

  return res.json();
}

export const api = {
  // Auth
  login: (email: string, password: string) =>
    request<{ success: boolean; user: User; token: string }>('/auth/login', {
      method: 'POST',
      body: JSON.stringify({ email, password }),
    }),

  forgotPassword: (email: string) =>
    request<{ success: boolean; message: string }>('/auth/forgot-password', {
      method: 'POST',
      body: JSON.stringify({ email }),
    }),

  // Health & DB Status
  getDbStatus: () => request<DatabaseStatus>('/config/status'),

  // Dashboard
  getStats: () => request<DashboardStats>('/dashboard/stats'),

  // Employees
  getEmployees: (params?: { search?: string; department_id?: string }) => {
    const q = new URLSearchParams();
    if (params?.search) q.set('search', params.search);
    if (params?.department_id) q.set('department_id', params.department_id);
    const query = q.toString() ? `?${q.toString()}` : '';
    return request<Employee[]>(`/employees${query}`);
  },

  getEmployee: (id: string) => request<Employee>(`/employees/${id}`),

  createEmployee: (data: Partial<Employee>) =>
    request<Employee>('/employees', {
      method: 'POST',
      body: JSON.stringify(data),
    }),

  updateEmployee: (id: string, data: Partial<Employee>) =>
    request<Employee>(`/employees/${id}`, {
      method: 'PUT',
      body: JSON.stringify(data),
    }),

  deleteEmployee: (id: string) =>
    request<{ success: boolean }>(`/employees/${id}`, {
      method: 'DELETE',
    }),

  // Departments
  getDepartments: () => request<Department[]>('/departments'),

  createDepartment: (data: Partial<Department>) =>
    request<Department>('/departments', {
      method: 'POST',
      body: JSON.stringify(data),
    }),

  updateDepartment: (id: string, data: Partial<Department>) =>
    request<Department>(`/departments/${id}`, {
      method: 'PUT',
      body: JSON.stringify(data),
    }),

  deleteDepartment: (id: string) =>
    request<{ success: boolean }>(`/departments/${id}`, {
      method: 'DELETE',
    }),

  // Attendance
  getAttendance: (params?: { date?: string; employee_id?: string }) => {
    const q = new URLSearchParams();
    if (params?.date) q.set('date', params.date);
    if (params?.employee_id) q.set('employee_id', params.employee_id);
    const query = q.toString() ? `?${q.toString()}` : '';
    return request<Attendance[]>(`/attendance${query}`);
  },

  markAttendance: (data: { employee_id: string; date: string; status: Attendance['status']; check_in?: string; check_out?: string }) =>
    request<Attendance>('/attendance', {
      method: 'POST',
      body: JSON.stringify(data),
    }),

  // Leaves
  getLeaves: (params?: { employee_id?: string; status?: string }) => {
    const q = new URLSearchParams();
    if (params?.employee_id) q.set('employee_id', params.employee_id);
    if (params?.status) q.set('status', params.status);
    const query = q.toString() ? `?${q.toString()}` : '';
    return request<Leave[]>(`/leaves${query}`);
  },

  applyLeave: (data: { employee_id: string; leave_type: string; start_date: string; end_date: string; reason: string }) =>
    request<Leave>('/leaves', {
      method: 'POST',
      body: JSON.stringify(data),
    }),

  updateLeaveStatus: (id: string, status: 'Approved' | 'Rejected', approved_by: string) =>
    request<Leave>(`/leaves/${id}/status`, {
      method: 'PUT',
      body: JSON.stringify({ status, approved_by }),
    }),

  // Salaries
  getSalaries: (params?: { employee_id?: string; month_year?: string }) => {
    const q = new URLSearchParams();
    if (params?.employee_id) q.set('employee_id', params.employee_id);
    if (params?.month_year) q.set('month_year', params.month_year);
    const query = q.toString() ? `?${q.toString()}` : '';
    return request<SalaryRecord[]>(`/salaries${query}`);
  },

  createSalary: (data: Partial<SalaryRecord>) =>
    request<SalaryRecord>('/salaries', {
      method: 'POST',
      body: JSON.stringify(data),
    }),

  // Performance
  getPerformance: (params?: { employee_id?: string }) => {
    const q = new URLSearchParams();
    if (params?.employee_id) q.set('employee_id', params.employee_id);
    const query = q.toString() ? `?${q.toString()}` : '';
    return request<Performance[]>(`/performance${query}`);
  },

  createPerformance: (data: Partial<Performance>) =>
    request<Performance>('/performance', {
      method: 'POST',
      body: JSON.stringify(data),
    }),

  deletePerformance: (id: string) =>
    request<{ success: boolean }>(`/performance/${id}`, {
      method: 'DELETE',
    }),

  // Reports
  getReportsSummary: () =>
    request<{
      employees: Employee[];
      departments: Department[];
      attendance: Attendance[];
      leaves: Leave[];
      salaries: SalaryRecord[];
      performance: Performance[];
      generatedAt: string;
    }>('/reports/summary'),
};
