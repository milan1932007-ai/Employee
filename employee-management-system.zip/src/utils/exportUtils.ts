import * as XLSX from 'xlsx';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';

export function exportToExcel(data: Record<string, any>[], fileName: string, sheetName: string = 'Sheet1') {
  try {
    const worksheet = XLSX.utils.json_to_sheet(data);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, sheetName);
    XLSX.writeFile(workbook, `${fileName}.xlsx`);
  } catch (err) {
    console.error('Excel Export Error:', err);
    alert('Failed to export Excel file. Please try again.');
  }
}

export function exportToPDF(
  title: string,
  columns: { header: string; dataKey: string }[],
  data: Record<string, any>[],
  fileName: string
) {
  try {
    const doc = new jsPDF();

    // Document header
    doc.setFontSize(18);
    doc.setTextColor(30, 41, 59); // Slate-800
    doc.text('Employee Management System', 14, 20);

    doc.setFontSize(13);
    doc.setTextColor(79, 70, 229); // Indigo-600
    doc.text(title, 14, 28);

    doc.setFontSize(9);
    doc.setTextColor(100, 116, 139); // Slate-500
    doc.text(`Generated on: ${new Date().toLocaleString()} | Total Records: ${data.length}`, 14, 34);

    // Render Table
    autoTable(doc, {
      startY: 40,
      head: [columns.map((c) => c.header)],
      body: data.map((row) => columns.map((col) => (row[col.dataKey] !== undefined ? String(row[col.dataKey]) : ''))),
      headStyles: {
        fillColor: [79, 70, 229], // Indigo
        textColor: [255, 255, 255],
        fontStyle: 'bold',
        fontSize: 9,
      },
      styles: {
        fontSize: 8,
        cellPadding: 3,
        overflow: 'linebreak',
      },
      alternateRowStyles: {
        fillColor: [248, 250, 252],
      },
    });

    doc.save(`${fileName}.pdf`);
  } catch (err) {
    console.error('PDF Export Error:', err);
    alert('Failed to export PDF file. Please try again.');
  }
}
