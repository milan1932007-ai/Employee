import React from 'react';
import {
  LayoutDashboard,
  Users,
  Building2,
  CalendarCheck2,
  Wallet,
  CalendarOff,
  Award,
  FileSpreadsheet,
  Database,
  ChevronRight,
  Menu,
  X,
} from 'lucide-react';
import type { UserRole } from '../types.ts';

export type ActiveTab =
  | 'dashboard'
  | 'employees'
  | 'departments'
  | 'attendance'
  | 'salaries'
  | 'leaves'
  | 'performance'
  | 'reports'
  | 'database';

interface SidebarProps {
  activeTab: ActiveTab;
  onSelectTab: (tab: ActiveTab) => void;
  userRole: UserRole;
  mobileOpen: boolean;
  onToggleMobile: () => void;
  pendingLeavesCount?: number;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeTab,
  onSelectTab,
  userRole,
  mobileOpen,
  onToggleMobile,
  pendingLeavesCount = 0,
}) => {
  const navItems = [
    { id: 'dashboard' as ActiveTab, label: 'Dashboard', icon: LayoutDashboard, roles: ['Admin', 'HR Manager', 'Employee'] },
    { id: 'employees' as ActiveTab, label: 'Employees', icon: Users, roles: ['Admin', 'HR Manager'] },
    { id: 'departments' as ActiveTab, label: 'Departments', icon: Building2, roles: ['Admin', 'HR Manager'] },
    { id: 'attendance' as ActiveTab, label: 'Attendance', icon: CalendarCheck2, roles: ['Admin', 'HR Manager', 'Employee'] },
    { id: 'salaries' as ActiveTab, label: 'Salaries & Payroll', icon: Wallet, roles: ['Admin', 'HR Manager', 'Employee'] },
    { id: 'leaves' as ActiveTab, label: 'Leave Requests', icon: CalendarOff, roles: ['Admin', 'HR Manager', 'Employee'], badge: pendingLeavesCount },
    { id: 'performance' as ActiveTab, label: 'Performance', icon: Award, roles: ['Admin', 'HR Manager', 'Employee'] },
    { id: 'reports' as ActiveTab, label: 'Reports & Export', icon: FileSpreadsheet, roles: ['Admin', 'HR Manager'] },
    { id: 'database' as ActiveTab, label: 'Database & SQL', icon: Database, roles: ['Admin'] },
  ];

  const visibleItems = navItems.filter((item) => item.roles.includes(userRole));

  const content = (
    <div className="flex h-full flex-col justify-between p-4 bg-white dark:bg-slate-900 border-r border-slate-200 dark:border-slate-800 transition-colors">
      <div className="space-y-6">
        <div className="px-2">
          <div className="text-[11px] font-bold uppercase tracking-wider text-slate-400 dark:text-slate-500">
            Main Navigation
          </div>
        </div>

        <nav className="space-y-1">
          {visibleItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => {
                  onSelectTab(item.id);
                  if (mobileOpen) onToggleMobile();
                }}
                className={`group flex w-full items-center justify-between rounded-xl px-3 py-2.5 text-sm font-semibold transition-all ${
                  isActive
                    ? 'bg-indigo-600 text-white shadow-md shadow-indigo-200 dark:shadow-none'
                    : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900 dark:text-slate-400 dark:hover:bg-slate-800 dark:hover:text-slate-100'
                }`}
              >
                <div className="flex items-center gap-3">
                  <Icon
                    className={`h-4 w-4 transition-transform group-hover:scale-110 ${
                      isActive ? 'text-white' : 'text-slate-400 group-hover:text-indigo-600 dark:group-hover:text-indigo-400'
                    }`}
                  />
                  <span>{item.label}</span>
                </div>

                <div className="flex items-center gap-1.5">
                  {item.badge !== undefined && item.badge > 0 && (
                    <span
                      className={`flex h-5 items-center justify-center rounded-full px-1.5 text-[10px] font-bold ${
                        isActive
                          ? 'bg-white text-indigo-600'
                          : 'bg-amber-100 text-amber-800 dark:bg-amber-900/50 dark:text-amber-300'
                      }`}
                    >
                      {item.badge}
                    </span>
                  )}
                  {isActive && <ChevronRight className="h-4 w-4 text-white/80" />}
                </div>
              </button>
            );
          })}
        </nav>
      </div>

      {/* Role info card in bottom of sidebar */}
      <div className="rounded-xl border border-slate-200 bg-slate-50/80 p-3 dark:border-slate-800 dark:bg-slate-800/60">
        <div className="flex items-center justify-between text-xs">
          <span className="font-semibold text-slate-700 dark:text-slate-300">Access Mode</span>
          <span className="rounded bg-indigo-100 px-1.5 py-0.5 text-[10px] font-bold text-indigo-700 dark:bg-indigo-900/60 dark:text-indigo-300">
            {userRole}
          </span>
        </div>
        <p className="mt-1 text-[11px] text-slate-500 dark:text-slate-400 leading-tight">
          {userRole === 'Admin' && 'Full administrative governance, payroll, and schema control.'}
          {userRole === 'HR Manager' && 'Department operations, staff profiles, attendance and leaves.'}
          {userRole === 'Employee' && 'Self-service attendance check-in, leaves, and payslips.'}
        </p>
      </div>
    </div>
  );

  return (
    <>
      {/* Mobile Toggle Button */}
      <div className="fixed bottom-4 right-4 z-50 md:hidden">
        <button
          onClick={onToggleMobile}
          className="flex h-12 w-12 items-center justify-center rounded-full bg-indigo-600 text-white shadow-xl hover:bg-indigo-700 focus:outline-none"
          aria-label="Toggle navigation menu"
        >
          {mobileOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
        </button>
      </div>

      {/* Desktop Sidebar */}
      <aside className="hidden md:block w-64 shrink-0 overflow-y-auto">
        {content}
      </aside>

      {/* Mobile Drawer Overlay */}
      {mobileOpen && (
        <div className="fixed inset-0 z-40 flex md:hidden">
          <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm" onClick={onToggleMobile} />
          <div className="relative flex w-4/5 max-w-xs flex-1 flex-col">
            {content}
          </div>
        </div>
      )}
    </>
  );
};
