import React from 'react';
import {
  Users,
  Building2,
  UserCheck,
  UserX,
  DollarSign,
  ArrowUpRight,
  TrendingUp,
  Clock,
  CheckCircle,
  Calendar,
  AlertCircle,
  Plus,
  FileText,
  CreditCard,
} from 'lucide-react';
import type { DashboardStats, UserRole } from '../types.ts';
import type { ActiveTab } from './Sidebar.tsx';

interface DashboardViewProps {
  stats: DashboardStats | null;
  loading: boolean;
  onNavigate: (tab: ActiveTab) => void;
  userRole: UserRole;
  onRefresh: () => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  stats,
  loading,
  onNavigate,
  userRole,
  onRefresh,
}) => {
  if (loading || !stats) {
    return (
      <div className="flex h-96 w-full items-center justify-center">
        <div className="flex flex-col items-center gap-3 text-slate-400">
          <div className="h-8 w-8 animate-spin rounded-full border-4 border-indigo-600 border-t-transparent" />
          <span className="text-sm font-medium">Loading organization dashboard...</span>
        </div>
      </div>
    );
  }

  const attendanceRate = stats.totalEmployees > 0
    ? Math.round((stats.presentToday / stats.totalEmployees) * 100)
    : 0;

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between rounded-2xl bg-gradient-to-r from-indigo-900 via-indigo-800 to-slate-900 p-6 text-white shadow-xl">
        <div>
          <div className="inline-flex items-center gap-1.5 rounded-full bg-indigo-500/30 px-3 py-1 text-xs font-semibold tracking-wide text-indigo-200 border border-indigo-400/30">
            <TrendingUp className="h-3.5 w-3.5 text-indigo-300" />
            Live Enterprise Overview
          </div>
          <h2 className="mt-2 text-2xl sm:text-3xl font-bold tracking-tight">
            Organization Performance
          </h2>
          <p className="mt-1 text-sm text-indigo-200/90 max-w-xl">
            Real-time workforce attendance, departmental distribution, and monthly payroll budget metrics.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {userRole !== 'Employee' && (
            <button
              onClick={() => onNavigate('employees')}
              className="inline-flex items-center gap-1.5 rounded-xl bg-indigo-500 px-3.5 py-2.5 text-xs font-semibold text-white shadow-sm hover:bg-indigo-400 transition-colors"
            >
              <Plus className="h-3.5 w-3.5" />
              Add Employee
            </button>
          )}
          <button
            onClick={() => onNavigate('attendance')}
            className="inline-flex items-center gap-1.5 rounded-xl bg-white/10 px-3.5 py-2.5 text-xs font-semibold text-white backdrop-blur-md hover:bg-white/20 transition-colors"
          >
            <Calendar className="h-3.5 w-3.5" />
            Mark Attendance
          </button>
        </div>
      </div>

      {/* KPI Cards Grid */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-5">
        {/* Card 1: Total Employees */}
        <div
          onClick={() => onNavigate('employees')}
          className="group cursor-pointer rounded-2xl border border-slate-200 bg-white p-5 shadow-sm hover:shadow-md dark:border-slate-800 dark:bg-slate-900 transition-all"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">
              Total Employees
            </span>
            <div className="rounded-xl bg-indigo-50 p-2.5 text-indigo-600 dark:bg-indigo-950/60 dark:text-indigo-400 group-hover:scale-110 transition-transform">
              <Users className="h-5 w-5" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white">
              {stats.totalEmployees}
            </span>
            <span className="text-xs font-medium text-emerald-600 dark:text-emerald-400 flex items-center">
              Active staff
            </span>
          </div>
        </div>

        {/* Card 2: Total Departments */}
        <div
          onClick={() => onNavigate('departments')}
          className="group cursor-pointer rounded-2xl border border-slate-200 bg-white p-5 shadow-sm hover:shadow-md dark:border-slate-800 dark:bg-slate-900 transition-all"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">
              Departments
            </span>
            <div className="rounded-xl bg-cyan-50 p-2.5 text-cyan-600 dark:bg-cyan-950/60 dark:text-cyan-400 group-hover:scale-110 transition-transform">
              <Building2 className="h-5 w-5" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white">
              {stats.totalDepartments}
            </span>
            <span className="text-xs font-medium text-slate-500 dark:text-slate-400">
              Divisions
            </span>
          </div>
        </div>

        {/* Card 3: Present Today */}
        <div
          onClick={() => onNavigate('attendance')}
          className="group cursor-pointer rounded-2xl border border-slate-200 bg-white p-5 shadow-sm hover:shadow-md dark:border-slate-800 dark:bg-slate-900 transition-all"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">
              Present Today
            </span>
            <div className="rounded-xl bg-emerald-50 p-2.5 text-emerald-600 dark:bg-emerald-950/60 dark:text-emerald-400 group-hover:scale-110 transition-transform">
              <UserCheck className="h-5 w-5" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl sm:text-3xl font-extrabold text-emerald-600 dark:text-emerald-400">
              {stats.presentToday}
            </span>
            <span className="text-xs font-medium text-slate-500 dark:text-slate-400">
              {attendanceRate}% rate
            </span>
          </div>
        </div>

        {/* Card 4: Absent Today */}
        <div
          onClick={() => onNavigate('attendance')}
          className="group cursor-pointer rounded-2xl border border-slate-200 bg-white p-5 shadow-sm hover:shadow-md dark:border-slate-800 dark:bg-slate-900 transition-all"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">
              Absent / Leave
            </span>
            <div className="rounded-xl bg-rose-50 p-2.5 text-rose-600 dark:bg-rose-950/60 dark:text-rose-400 group-hover:scale-110 transition-transform">
              <UserX className="h-5 w-5" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl sm:text-3xl font-extrabold text-rose-600 dark:text-rose-400">
              {stats.absentToday}
            </span>
            <span className="text-xs font-medium text-slate-500 dark:text-slate-400">
              {stats.onLeaveToday > 0 ? `(${stats.onLeaveToday} on leave)` : 'Unexcused'}
            </span>
          </div>
        </div>

        {/* Card 5: Monthly Salary Expenses */}
        <div
          onClick={() => onNavigate('salaries')}
          className="group cursor-pointer rounded-2xl border border-slate-200 bg-white p-5 shadow-sm hover:shadow-md dark:border-slate-800 dark:bg-slate-900 transition-all"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">
              Monthly Payroll
            </span>
            <div className="rounded-xl bg-amber-50 p-2.5 text-amber-600 dark:bg-amber-950/60 dark:text-amber-400 group-hover:scale-110 transition-transform">
              <DollarSign className="h-5 w-5" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-1">
            <span className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white">
              ${(stats.monthlySalaryExpenses / 1000).toFixed(1)}k
            </span>
            <span className="text-xs font-medium text-slate-500 dark:text-slate-400">
              /mo est.
            </span>
          </div>
        </div>
      </div>

      {/* Two Columns: Attendance Breakdown & Recent Activities */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        {/* Department Distribution (Left 2 Columns) */}
        <div className="lg:col-span-2 rounded-2xl border border-slate-200 bg-white p-6 shadow-sm dark:border-slate-800 dark:bg-slate-900">
          <div className="flex items-center justify-between border-b border-slate-100 pb-4 dark:border-slate-800">
            <div>
              <h3 className="text-base font-bold text-slate-900 dark:text-white">
                Departmental Workforce Distribution
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Staff count allocation across organizational units
              </p>
            </div>
            <button
              onClick={() => onNavigate('departments')}
              className="text-xs font-semibold text-indigo-600 hover:text-indigo-700 dark:text-indigo-400 flex items-center gap-1"
            >
              <span>Manage</span>
              <ArrowUpRight className="h-3.5 w-3.5" />
            </button>
          </div>

          <div className="mt-6 space-y-4">
            {stats.departmentDistribution.map((dept) => {
              const pct = stats.totalEmployees > 0
                ? Math.round((dept.count / stats.totalEmployees) * 100)
                : 0;
              return (
                <div key={dept.name} className="space-y-1.5">
                  <div className="flex items-center justify-between text-xs font-semibold">
                    <span className="text-slate-700 dark:text-slate-300">{dept.name}</span>
                    <span className="text-slate-500 dark:text-slate-400">
                      {dept.count} members ({pct}%)
                    </span>
                  </div>
                  <div className="h-2.5 w-full rounded-full bg-slate-100 dark:bg-slate-800 overflow-hidden">
                    <div
                      className="h-full rounded-full bg-indigo-600 transition-all duration-500"
                      style={{ width: `${pct}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>

          {/* Quick Actions Footer */}
          <div className="mt-8 pt-4 border-t border-slate-100 dark:border-slate-800 grid grid-cols-2 sm:grid-cols-4 gap-2">
            <button
              onClick={() => onNavigate('employees')}
              className="flex items-center justify-center gap-1.5 rounded-xl border border-slate-200 bg-slate-50 py-2 text-xs font-medium text-slate-700 hover:bg-slate-100 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-300"
            >
              <Users className="h-3.5 w-3.5 text-indigo-500" />
              <span>Employees</span>
            </button>
            <button
              onClick={() => onNavigate('leaves')}
              className="flex items-center justify-center gap-1.5 rounded-xl border border-slate-200 bg-slate-50 py-2 text-xs font-medium text-slate-700 hover:bg-slate-100 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-300"
            >
              <Clock className="h-3.5 w-3.5 text-amber-500" />
              <span>Leaves</span>
            </button>
            <button
              onClick={() => onNavigate('salaries')}
              className="flex items-center justify-center gap-1.5 rounded-xl border border-slate-200 bg-slate-50 py-2 text-xs font-medium text-slate-700 hover:bg-slate-100 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-300"
            >
              <CreditCard className="h-3.5 w-3.5 text-emerald-500" />
              <span>Payroll</span>
            </button>
            <button
              onClick={() => onNavigate('reports')}
              className="flex items-center justify-center gap-1.5 rounded-xl border border-slate-200 bg-slate-50 py-2 text-xs font-medium text-slate-700 hover:bg-slate-100 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-300"
            >
              <FileText className="h-3.5 w-3.5 text-cyan-500" />
              <span>Reports</span>
            </button>
          </div>
        </div>

        {/* Recent Employee Activities (Right Column) */}
        <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm dark:border-slate-800 dark:bg-slate-900 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between border-b border-slate-100 pb-4 dark:border-slate-800">
              <h3 className="text-base font-bold text-slate-900 dark:text-white">
                Recent Activities
              </h3>
              <button
                onClick={onRefresh}
                className="text-xs font-semibold text-slate-500 hover:text-indigo-600 dark:text-slate-400 dark:hover:text-indigo-400"
              >
                Refresh
              </button>
            </div>

            <div className="mt-4 space-y-3.5">
              {stats.recentActivities.map((act) => (
                <div key={act.id} className="flex items-start gap-3 text-xs">
                  <div className="mt-0.5 flex h-7 w-7 shrink-0 items-center justify-center rounded-lg bg-indigo-50 text-indigo-600 dark:bg-indigo-950/60 dark:text-indigo-400">
                    <CheckCircle className="h-3.5 w-3.5" />
                  </div>
                  <div className="space-y-0.5">
                    <p className="font-semibold text-slate-800 dark:text-slate-200 leading-snug">
                      {act.action}
                    </p>
                    <div className="flex items-center gap-2 text-[10px] text-slate-400">
                      <span>By {act.user}</span>
                      <span>•</span>
                      <span>{act.timestamp}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="mt-6 rounded-xl bg-indigo-50/70 p-3 dark:bg-indigo-950/30 border border-indigo-100 dark:border-indigo-900/50">
            <div className="flex items-center gap-2 text-xs font-bold text-indigo-900 dark:text-indigo-200">
              <AlertCircle className="h-3.5 w-3.5 text-indigo-600 dark:text-indigo-400" />
              <span>Real-Time Sync Active</span>
            </div>
            <p className="mt-1 text-[11px] text-indigo-700/80 dark:text-indigo-300/80 leading-tight">
              All records sync directly with the unified database backend and RESTful controllers.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
