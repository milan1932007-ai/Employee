import React, { useState } from 'react';
import {
  Bell,
  Sun,
  Moon,
  ShieldCheck,
  UserCheck,
  Briefcase,
  Database,
  LogOut,
  ChevronDown,
  Mail,
  CheckCircle2,
  Clock,
} from 'lucide-react';
import type { User, UserRole } from '../types.ts';

interface NavbarProps {
  currentUser: User;
  onLogout: () => void;
  onRoleSwitch: (role: UserRole) => void;
  darkMode: boolean;
  onToggleDarkMode: () => void;
  onOpenDbModal: () => void;
  isSupabaseLive?: boolean;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentUser,
  onLogout,
  onRoleSwitch,
  darkMode,
  onToggleDarkMode,
  onOpenDbModal,
  isSupabaseLive,
}) => {
  const [showRoleDropdown, setShowRoleDropdown] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);
  const [unreadCount, setUnreadCount] = useState(3);

  const notifications = [
    { id: 1, title: 'Leave Approved', desc: 'Emma Watson leave application approved for 3 days.', time: '10m ago', unread: true },
    { id: 2, title: 'Payroll Run Complete', desc: 'Monthly salary distribution for August 2026 processed.', time: '1h ago', unread: true },
    { id: 3, title: 'New Review Added', desc: 'Sarah Jenkins submitted evaluation for Marcus Vance.', time: '3h ago', unread: true },
    { id: 4, title: 'Daily Attendance Report', desc: 'Attendance marked: 5 present, 1 on leave.', time: '5h ago', unread: false },
  ];

  return (
    <header className="sticky top-0 z-30 flex h-16 w-full items-center justify-between border-b border-slate-200 bg-white/90 px-4 sm:px-6 backdrop-blur-md dark:border-slate-800 dark:bg-slate-900/90 transition-colors">
      <div className="flex items-center gap-3">
        <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-indigo-600 text-white font-bold shadow-md shadow-indigo-200 dark:shadow-none">
          EM
        </div>
        <div>
          <h1 className="text-base font-bold tracking-tight text-slate-900 dark:text-white leading-tight">
            Employee<span className="text-indigo-600 dark:text-indigo-400">Hub</span>
          </h1>
          <p className="hidden sm:block text-[11px] font-medium text-slate-500 dark:text-slate-400">
            Enterprise Management System
          </p>
        </div>
      </div>

      {/* Right Action Icons & Profile */}
      <div className="flex items-center gap-2 sm:gap-3">
        {/* Database Status Pill */}
        <button
          onClick={onOpenDbModal}
          className="hidden md:flex items-center gap-1.5 rounded-lg border border-slate-200 bg-slate-50 px-2.5 py-1.5 text-xs font-semibold text-slate-700 hover:bg-slate-100 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 transition-colors"
          title="Database Connection Status"
        >
          <Database className="h-3.5 w-3.5 text-indigo-500" />
          <span>{isSupabaseLive ? 'Supabase Live' : 'Local DB / Supabase Ready'}</span>
          <span className={`h-2 w-2 rounded-full ${isSupabaseLive ? 'bg-emerald-500' : 'bg-amber-400 animate-pulse'}`} />
        </button>

        {/* Role Switcher Pill */}
        <div className="relative">
          <button
            onClick={() => setShowRoleDropdown(!showRoleDropdown)}
            className="flex items-center gap-1.5 rounded-lg border border-indigo-200 bg-indigo-50/80 px-2.5 py-1.5 text-xs font-semibold text-indigo-700 hover:bg-indigo-100 dark:border-indigo-900 dark:bg-indigo-950/60 dark:text-indigo-300 transition-colors"
          >
            {currentUser.role === 'Admin' && <ShieldCheck className="h-3.5 w-3.5" />}
            {currentUser.role === 'HR Manager' && <Briefcase className="h-3.5 w-3.5" />}
            {currentUser.role === 'Employee' && <UserCheck className="h-3.5 w-3.5" />}
            <span>Role: {currentUser.role}</span>
            <ChevronDown className="h-3 w-3 opacity-70" />
          </button>

          {showRoleDropdown && (
            <div className="absolute right-0 mt-2 w-48 rounded-xl border border-slate-200 bg-white p-1.5 shadow-xl dark:border-slate-700 dark:bg-slate-800 z-50 animate-in fade-in zoom-in-95">
              <div className="px-2 py-1 text-[10px] font-bold uppercase tracking-wider text-slate-400">
                Switch Active Role
              </div>
              {(['Admin', 'HR Manager', 'Employee'] as UserRole[]).map((role) => (
                <button
                  key={role}
                  onClick={() => {
                    onRoleSwitch(role);
                    setShowRoleDropdown(false);
                  }}
                  className={`flex w-full items-center justify-between rounded-lg px-2.5 py-2 text-xs font-medium transition-colors ${
                    currentUser.role === role
                      ? 'bg-indigo-600 text-white'
                      : 'text-slate-700 hover:bg-slate-100 dark:text-slate-200 dark:hover:bg-slate-700'
                  }`}
                >
                  <span>{role}</span>
                  {currentUser.role === role && <CheckCircle2 className="h-3.5 w-3.5" />}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Dark/Light mode toggle */}
        <button
          onClick={onToggleDarkMode}
          className="rounded-lg p-2 text-slate-500 hover:bg-slate-100 dark:text-slate-400 dark:hover:bg-slate-800 transition-colors"
          aria-label="Toggle theme"
        >
          {darkMode ? <Sun className="h-4 w-4 text-amber-400" /> : <Moon className="h-4 w-4 text-slate-600" />}
        </button>

        {/* Notifications Dropdown */}
        <div className="relative">
          <button
            onClick={() => {
              setShowNotifications(!showNotifications);
              if (!showNotifications) setUnreadCount(0);
            }}
            className="relative rounded-lg p-2 text-slate-500 hover:bg-slate-100 dark:text-slate-400 dark:hover:bg-slate-800 transition-colors"
            aria-label="View notifications"
          >
            <Bell className="h-4 w-4" />
            {unreadCount > 0 && (
              <span className="absolute top-1.5 right-1.5 flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-indigo-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-indigo-600"></span>
              </span>
            )}
          </button>

          {showNotifications && (
            <div className="absolute right-0 mt-2 w-80 rounded-xl border border-slate-200 bg-white p-2 shadow-2xl dark:border-slate-700 dark:bg-slate-800 z-50 animate-in fade-in">
              <div className="flex items-center justify-between border-b border-slate-100 px-3 py-2 dark:border-slate-700">
                <span className="text-xs font-bold text-slate-800 dark:text-white">Email & System Alerts</span>
                <span className="rounded bg-indigo-100 px-1.5 py-0.5 text-[10px] font-semibold text-indigo-700 dark:bg-indigo-950 dark:text-indigo-300">
                  {notifications.length} alerts
                </span>
              </div>
              <div className="max-h-72 divide-y divide-slate-100 overflow-y-auto dark:divide-slate-700">
                {notifications.map((n) => (
                  <div key={n.id} className="p-2.5 hover:bg-slate-50 dark:hover:bg-slate-700/50 rounded-lg transition-colors">
                    <div className="flex items-center justify-between text-xs font-semibold text-slate-800 dark:text-slate-200">
                      <span className="flex items-center gap-1.5">
                        <Mail className="h-3 w-3 text-indigo-500" />
                        {n.title}
                      </span>
                      <span className="text-[10px] text-slate-400 flex items-center gap-0.5">
                        <Clock className="h-2.5 w-2.5" />
                        {n.time}
                      </span>
                    </div>
                    <p className="mt-1 text-[11px] text-slate-500 dark:text-slate-400 leading-snug">
                      {n.desc}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* User Profile avatar + logout */}
        <div className="flex items-center gap-2 border-l border-slate-200 pl-2 sm:pl-3 dark:border-slate-800">
          <img
            src={currentUser.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&h=100&fit=crop&crop=faces'}
            alt={currentUser.full_name}
            className="h-8 w-8 rounded-full object-cover border border-slate-200 dark:border-slate-700 shadow-sm"
          />
          <div className="hidden lg:block text-left">
            <div className="text-xs font-semibold text-slate-800 dark:text-slate-200 truncate max-w-[120px]">
              {currentUser.full_name}
            </div>
            <div className="text-[10px] text-slate-500 dark:text-slate-400 truncate max-w-[120px]">
              {currentUser.email}
            </div>
          </div>

          <button
            onClick={onLogout}
            className="rounded-lg p-1.5 text-slate-400 hover:bg-rose-50 hover:text-rose-600 dark:hover:bg-rose-950/40 dark:hover:text-rose-400 transition-colors"
            title="Logout"
          >
            <LogOut className="h-4 w-4" />
          </button>
        </div>
      </div>
    </header>
  );
};
