import React, { useState } from 'react';
import {
  Building2,
  Plus,
  Edit2,
  Trash2,
  Users,
  UserCheck,
  X,
  FileText,
  Briefcase,
} from 'lucide-react';
import type { Department, Employee, UserRole } from '../types.ts';

interface DepartmentsViewProps {
  departments: Department[];
  employees: Employee[];
  userRole: UserRole;
  onSaveDepartment: (data: Partial<Department>, isEdit: boolean) => Promise<void>;
  onDeleteDepartment: (id: string) => Promise<void>;
}

export const DepartmentsView: React.FC<DepartmentsViewProps> = ({
  departments,
  employees,
  userRole,
  onSaveDepartment,
  onDeleteDepartment,
}) => {
  const [showModal, setShowModal] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [currentDept, setCurrentDept] = useState<Partial<Department>>({});
  const [saving, setSaving] = useState(false);

  const [viewingDeptEmployees, setViewingDeptEmployees] = useState<Department | null>(null);

  const handleOpenAdd = () => {
    setCurrentDept({
      department_name: '',
      department_head: '',
      description: '',
    });
    setIsEditing(false);
    setShowModal(true);
  };

  const handleOpenEdit = (dept: Department) => {
    setCurrentDept({ ...dept });
    setIsEditing(true);
    setShowModal(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentDept.department_name || !currentDept.department_head) {
      alert('Department name and department head are required.');
      return;
    }
    setSaving(true);
    try {
      await onSaveDepartment(currentDept, isEditing);
      setShowModal(false);
    } catch (err: any) {
      alert(err.message || 'Failed to save department.');
    } finally {
      setSaving(false);
    }
  };

  const deptEmployees = viewingDeptEmployees
    ? employees.filter((e) => e.department_id === viewingDeptEmployees.id)
    : [];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h2 className="text-xl font-bold tracking-tight text-slate-900 dark:text-white">
            Department Management
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Structure divisions, department leadership, team allocations, and organizational hierarchies.
          </p>
        </div>

        {userRole !== 'Employee' && (
          <button
            onClick={handleOpenAdd}
            className="inline-flex items-center gap-1.5 rounded-xl bg-indigo-600 px-3.5 py-2 text-xs font-semibold text-white shadow-sm hover:bg-indigo-700 transition-colors"
          >
            <Plus className="h-3.5 w-3.5" />
            <span>Add Department</span>
          </button>
        )}
      </div>

      {/* Department Cards Grid */}
      <div className="grid grid-cols-1 gap-5 md:grid-cols-2 lg:grid-cols-3">
        {departments.map((dept) => {
          const count = employees.filter((e) => e.department_id === dept.id).length;
          return (
            <div
              key={dept.id}
              className="flex flex-col justify-between rounded-2xl border border-slate-200 bg-white p-6 shadow-sm dark:border-slate-800 dark:bg-slate-900 transition-all hover:shadow-md"
            >
              <div>
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-3">
                    <div className="rounded-xl bg-indigo-50 p-2.5 text-indigo-600 dark:bg-indigo-950/60 dark:text-indigo-400">
                      <Building2 className="h-5 w-5" />
                    </div>
                    <div>
                      <h3 className="font-bold text-slate-900 dark:text-white text-base">
                        {dept.department_name}
                      </h3>
                      <p className="text-xs font-medium text-slate-500 dark:text-slate-400 flex items-center gap-1 mt-0.5">
                        <UserCheck className="h-3.5 w-3.5 text-indigo-500" />
                        <span>Head: {dept.department_head}</span>
                      </p>
                    </div>
                  </div>

                  {userRole !== 'Employee' && (
                    <div className="flex items-center gap-1">
                      <button
                        onClick={() => handleOpenEdit(dept)}
                        className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-100 hover:text-amber-600 dark:hover:bg-slate-800"
                        title="Edit Department"
                      >
                        <Edit2 className="h-3.5 w-3.5" />
                      </button>
                      <button
                        onClick={() => {
                          if (confirm(`Are you sure you want to delete ${dept.department_name}?`)) {
                            onDeleteDepartment(dept.id);
                          }
                        }}
                        className="rounded-lg p-1.5 text-slate-400 hover:bg-rose-50 hover:text-rose-600 dark:hover:bg-rose-950/50"
                        title="Delete Department"
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                      </button>
                    </div>
                  )}
                </div>

                <p className="mt-4 text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                  {dept.description || 'No description provided.'}
                </p>
              </div>

              <div className="mt-6 border-t border-slate-100 pt-4 dark:border-slate-800 flex items-center justify-between">
                <div className="flex items-center gap-1.5 text-xs font-bold text-slate-700 dark:text-slate-300">
                  <Users className="h-4 w-4 text-indigo-500" />
                  <span>{count} Staff Member{count === 1 ? '' : 's'}</span>
                </div>

                <button
                  onClick={() => setViewingDeptEmployees(dept)}
                  className="rounded-lg bg-indigo-50 px-2.5 py-1.5 text-xs font-semibold text-indigo-600 hover:bg-indigo-100 dark:bg-indigo-950/60 dark:text-indigo-400 transition-colors"
                >
                  View Staff
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Modal 1: Add / Edit Department */}
      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
          <div className="relative w-full max-w-md rounded-2xl bg-white p-6 shadow-2xl dark:bg-slate-900 dark:border dark:border-slate-800">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3 dark:border-slate-800">
              <h3 className="text-base font-bold text-slate-900 dark:text-white">
                {isEditing ? 'Edit Department' : 'Create Department'}
              </h3>
              <button
                onClick={() => setShowModal(false)}
                className="rounded-lg p-1 text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="mt-4 space-y-3.5">
              <div>
                <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                  Department Name *
                </label>
                <input
                  type="text"
                  required
                  value={currentDept.department_name || ''}
                  onChange={(e) => setCurrentDept({ ...currentDept, department_name: e.target.value })}
                  placeholder="e.g. Quality Assurance"
                  className="mt-1 w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs font-medium dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                  Department Head / Director *
                </label>
                <input
                  type="text"
                  required
                  value={currentDept.department_head || ''}
                  onChange={(e) => setCurrentDept({ ...currentDept, department_head: e.target.value })}
                  placeholder="e.g. Rachel Adams"
                  className="mt-1 w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs font-medium dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                  Description
                </label>
                <textarea
                  rows={3}
                  value={currentDept.description || ''}
                  onChange={(e) => setCurrentDept({ ...currentDept, description: e.target.value })}
                  placeholder="Primary roles, functions, and key objectives..."
                  className="mt-1 w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs font-medium dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                />
              </div>

              <div className="mt-6 flex justify-end gap-2 border-t border-slate-100 pt-4 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowModal(false)}
                  className="rounded-xl border border-slate-200 px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-50 dark:border-slate-700 dark:text-slate-300"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={saving}
                  className="rounded-xl bg-indigo-600 px-4 py-2 text-xs font-semibold text-white shadow-sm hover:bg-indigo-700 disabled:opacity-50"
                >
                  {saving ? 'Saving...' : isEditing ? 'Update Department' : 'Create Department'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal 2: View Department Employees */}
      {viewingDeptEmployees && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
          <div className="relative w-full max-w-2xl rounded-2xl bg-white p-6 shadow-2xl dark:bg-slate-900 dark:border dark:border-slate-800">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3 dark:border-slate-800">
              <div>
                <h3 className="text-base font-bold text-slate-900 dark:text-white">
                  {viewingDeptEmployees.department_name} — Team Members
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  Head: {viewingDeptEmployees.department_head} • {deptEmployees.length} Total Members
                </p>
              </div>
              <button
                onClick={() => setViewingDeptEmployees(null)}
                className="rounded-lg p-1 text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <div className="mt-4 max-h-96 overflow-y-auto divide-y divide-slate-100 dark:divide-slate-800">
              {deptEmployees.length === 0 ? (
                <div className="py-8 text-center text-xs text-slate-400">
                  No employees assigned to this department yet.
                </div>
              ) : (
                deptEmployees.map((emp) => (
                  <div key={emp.id} className="flex items-center justify-between py-3">
                    <div className="flex items-center gap-3">
                      <img
                        src={emp.photo_url}
                        alt={emp.full_name}
                        className="h-10 w-10 rounded-full object-cover border border-slate-200 dark:border-slate-700"
                      />
                      <div>
                        <div className="font-bold text-slate-800 dark:text-slate-200 text-xs">
                          {emp.full_name}
                        </div>
                        <div className="text-[11px] text-indigo-600 dark:text-indigo-400 font-medium">
                          {emp.designation}
                        </div>
                        <div className="text-[10px] text-slate-400 font-mono">
                          {emp.employee_id} • {emp.email}
                        </div>
                      </div>
                    </div>

                    <div className="text-right">
                      <span className="inline-block rounded-full bg-emerald-50 px-2 py-0.5 text-[10px] font-bold text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-300">
                        {emp.status || 'Active'}
                      </span>
                      <div className="text-[11px] font-semibold text-slate-700 dark:text-slate-300 mt-1">
                        ${Number(emp.salary).toLocaleString()}/yr
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>

            <div className="mt-4 flex justify-end border-t border-slate-100 pt-3 dark:border-slate-800">
              <button
                onClick={() => setViewingDeptEmployees(null)}
                className="rounded-xl bg-slate-100 px-4 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-200 dark:bg-slate-800 dark:text-slate-300"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
