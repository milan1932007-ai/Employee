import React, { useState } from 'react';
import {
  CalendarCheck2,
  CheckCircle,
  XCircle,
  Clock,
  Calendar,
  Filter,
  FileSpreadsheet,
  Download,
  Plus,
  X,
  UserCheck,
} from 'lucide-react';
import type { Attendance, Employee, UserRole } from '../types.ts';
import { exportToExcel, exportToPDF } from '../utils/exportUtils.ts';

interface AttendanceViewProps {
  attendance: Attendance[];
  employees: Employee[];
  userRole: UserRole;
  onMarkAttendance: (data: {
    employee_id: string;
    date: string;
    status: Attendance['status'];
    check_in?: string;
    check_out?: string;
  }) => Promise<void>;
}

export const AttendanceView: React.FC<AttendanceViewProps> = ({
  attendance,
  employees,
  userRole,
  onMarkAttendance,
}) => {
  const todayStr = new Date().toISOString().split('T')[0];
  const [selectedDate, setSelectedDate] = useState(todayStr);
  const [selectedStatus, setSelectedStatus] = useState<string>('all');
  const [showMarkModal, setShowMarkModal] = useState(false);

  const [formEmployeeId, setFormEmployeeId] = useState(employees[0]?.employee_id || '');
  const [formDate, setFormDate] = useState(todayStr);
  const [formStatus, setFormStatus] = useState<Attendance['status']>('Present');
  const [formCheckIn, setFormCheckIn] = useState('09:00 AM');
  const [formCheckOut, setFormCheckOut] = useState('05:30 PM');
  const [saving, setSaving] = useState(false);

  // Filter attendance records
  const filteredAttendance = attendance.filter((a) => {
    const matchesDate = !selectedDate || a.date === selectedDate;
    const matchesStatus = selectedStatus === 'all' || a.status === selectedStatus;
    return matchesDate && matchesStatus;
  });

  const presentCount = attendance.filter((a) => a.date === selectedDate && (a.status === 'Present' || a.status === 'Half Day')).length;
  const absentCount = attendance.filter((a) => a.date === selectedDate && a.status === 'Absent').length;
  const leaveCount = attendance.filter((a) => a.date === selectedDate && a.status === 'On Leave').length;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formEmployeeId || !formDate || !formStatus) {
      alert('Please fill out all fields.');
      return;
    }
    setSaving(true);
    try {
      await onMarkAttendance({
        employee_id: formEmployeeId,
        date: formDate,
        status: formStatus,
        check_in: formStatus === 'Present' || formStatus === 'Half Day' ? formCheckIn : undefined,
        check_out: formStatus === 'Present' || formStatus === 'Half Day' ? formCheckOut : undefined,
      });
      setShowMarkModal(false);
    } catch (err: any) {
      alert(err.message || 'Failed to mark attendance.');
    } finally {
      setSaving(false);
    }
  };

  const handleExportExcel = () => {
    const data = filteredAttendance.map((a) => ({
      Date: a.date,
      'Employee ID': a.employee_id,
      'Employee Name': a.employee_name || employees.find((e) => e.employee_id === a.employee_id)?.full_name || a.employee_id,
      Status: a.status,
      'Check In': a.check_in || 'N/A',
      'Check Out': a.check_out || 'N/A',
    }));
    exportToExcel(data, `Attendance_Report_${selectedDate}`);
  };

  const handleExportPDF = () => {
    const columns = [
      { header: 'Date', dataKey: 'date' },
      { header: 'Employee ID', dataKey: 'employee_id' },
      { header: 'Employee Name', dataKey: 'employee_name' },
      { header: 'Status', dataKey: 'status' },
      { header: 'Check In', dataKey: 'check_in' },
      { header: 'Check Out', dataKey: 'check_out' },
    ];
    exportToPDF(`Daily Attendance Report (${selectedDate})`, columns, filteredAttendance, `Attendance_${selectedDate}`);
  };

  const getStatusBadge = (status: Attendance['status']) => {
    switch (status) {
      case 'Present':
        return (
          <span className="inline-flex items-center gap-1 rounded-full bg-emerald-50 px-2.5 py-0.5 text-xs font-bold text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-300">
            <CheckCircle className="h-3 w-3" />
            Present
          </span>
        );
      case 'Absent':
        return (
          <span className="inline-flex items-center gap-1 rounded-full bg-rose-50 px-2.5 py-0.5 text-xs font-bold text-rose-700 dark:bg-rose-950/60 dark:text-rose-300">
            <XCircle className="h-3 w-3" />
            Absent
          </span>
        );
      case 'Half Day':
        return (
          <span className="inline-flex items-center gap-1 rounded-full bg-amber-50 px-2.5 py-0.5 text-xs font-bold text-amber-700 dark:bg-amber-950/60 dark:text-amber-300">
            <Clock className="h-3 w-3" />
            Half Day
          </span>
        );
      case 'On Leave':
        return (
          <span className="inline-flex items-center gap-1 rounded-full bg-indigo-50 px-2.5 py-0.5 text-xs font-bold text-indigo-700 dark:bg-indigo-950/60 dark:text-indigo-300">
            <Calendar className="h-3 w-3" />
            On Leave
          </span>
        );
    }
  };

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h2 className="text-xl font-bold tracking-tight text-slate-900 dark:text-white">
            Attendance Tracking
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Daily check-in logs, monthly timesheets, absenteeism records, and verified punch timestamps.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={handleExportExcel}
            className="inline-flex items-center gap-1.5 rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs font-semibold text-slate-700 shadow-sm hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-300"
          >
            <FileSpreadsheet className="h-3.5 w-3.5 text-emerald-600" />
            <span>Excel</span>
          </button>
          <button
            onClick={handleExportPDF}
            className="inline-flex items-center gap-1.5 rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs font-semibold text-slate-700 shadow-sm hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-300"
          >
            <Download className="h-3.5 w-3.5 text-rose-600" />
            <span>PDF</span>
          </button>

          <button
            onClick={() => setShowMarkModal(true)}
            className="inline-flex items-center gap-1.5 rounded-xl bg-indigo-600 px-3.5 py-2 text-xs font-semibold text-white shadow-sm hover:bg-indigo-700 transition-colors"
          >
            <Plus className="h-3.5 w-3.5" />
            <span>Mark Attendance</span>
          </button>
        </div>
      </div>

      {/* Date Summary Cards */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-4">
        <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm dark:border-slate-800 dark:bg-slate-900">
          <div className="text-xs font-bold uppercase tracking-wider text-slate-400">
            Target Date
          </div>
          <div className="mt-2 flex items-center gap-2 font-mono text-base font-bold text-slate-900 dark:text-white">
            <Calendar className="h-4 w-4 text-indigo-500" />
            <span>{selectedDate}</span>
          </div>
        </div>

        <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm dark:border-slate-800 dark:bg-slate-900">
          <div className="text-xs font-bold uppercase tracking-wider text-emerald-600">
            Present
          </div>
          <div className="mt-2 text-2xl font-black text-emerald-600">
            {presentCount}
          </div>
        </div>

        <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm dark:border-slate-800 dark:bg-slate-900">
          <div className="text-xs font-bold uppercase tracking-wider text-rose-600">
            Absent
          </div>
          <div className="mt-2 text-2xl font-black text-rose-600">
            {absentCount}
          </div>
        </div>

        <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm dark:border-slate-800 dark:bg-slate-900">
          <div className="text-xs font-bold uppercase tracking-wider text-indigo-600">
            On Leave
          </div>
          <div className="mt-2 text-2xl font-black text-indigo-600">
            {leaveCount}
          </div>
        </div>
      </div>

      {/* Filter Bar */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between rounded-2xl border border-slate-200 bg-white p-3 shadow-sm dark:border-slate-800 dark:bg-slate-900">
        <div className="flex items-center gap-2">
          <label className="text-xs font-semibold text-slate-500">Filter Date:</label>
          <input
            type="date"
            value={selectedDate}
            onChange={(e) => setSelectedDate(e.target.value)}
            className="rounded-xl border border-slate-200 bg-slate-50 px-3 py-1.5 text-xs font-medium text-slate-800 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
          />
          <button
            onClick={() => setSelectedDate(todayStr)}
            className="rounded-xl bg-slate-100 px-2.5 py-1.5 text-xs font-semibold text-slate-600 hover:bg-slate-200 dark:bg-slate-800 dark:text-slate-300"
          >
            Today
          </button>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-xs font-semibold text-slate-500">Status:</span>
          <select
            value={selectedStatus}
            onChange={(e) => setSelectedStatus(e.target.value)}
            className="rounded-xl border border-slate-200 bg-slate-50 px-2.5 py-1.5 text-xs font-medium text-slate-800 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
          >
            <option value="all">All Statuses</option>
            <option value="Present">Present</option>
            <option value="Absent">Absent</option>
            <option value="Half Day">Half Day</option>
            <option value="On Leave">On Leave</option>
          </select>
        </div>
      </div>

      {/* Attendance Table */}
      <div className="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm dark:border-slate-800 dark:bg-slate-900">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="border-b border-slate-200 bg-slate-50/75 font-bold uppercase tracking-wider text-slate-500 dark:border-slate-800 dark:bg-slate-800/50 dark:text-slate-400">
              <tr>
                <th className="px-4 py-3.5">Employee</th>
                <th className="px-4 py-3.5">Employee ID</th>
                <th className="px-4 py-3.5">Date</th>
                <th className="px-4 py-3.5">Status</th>
                <th className="px-4 py-3.5">Check In</th>
                <th className="px-4 py-3.5">Check Out</th>
                <th className="px-4 py-3.5 text-right">Quick Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {filteredAttendance.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-12 text-center text-slate-400">
                    No attendance records for {selectedDate}. Click "Mark Attendance" to log a record.
                  </td>
                </tr>
              ) : (
                filteredAttendance.map((att) => {
                  const emp = employees.find((e) => e.employee_id === att.employee_id);
                  return (
                    <tr
                      key={att.id}
                      className="hover:bg-slate-50/80 dark:hover:bg-slate-800/50 transition-colors"
                    >
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-3">
                          <img
                            src={emp?.photo_url || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&h=100&fit=crop&crop=faces'}
                            alt={emp?.full_name || att.employee_id}
                            className="h-8 w-8 rounded-full object-cover border border-slate-200 dark:border-slate-700"
                          />
                          <div>
                            <div className="font-bold text-slate-900 dark:text-white">
                              {emp?.full_name || att.employee_name || att.employee_id}
                            </div>
                            <div className="text-[11px] text-slate-400">
                              {emp?.designation || 'Staff'}
                            </div>
                          </div>
                        </div>
                      </td>
                      <td className="px-4 py-3 font-mono font-semibold text-indigo-600 dark:text-indigo-400">
                        {att.employee_id}
                      </td>
                      <td className="px-4 py-3 font-medium text-slate-600 dark:text-slate-300">
                        {att.date}
                      </td>
                      <td className="px-4 py-3">
                        {getStatusBadge(att.status)}
                      </td>
                      <td className="px-4 py-3 font-mono text-slate-700 dark:text-slate-300">
                        {att.check_in || '—'}
                      </td>
                      <td className="px-4 py-3 font-mono text-slate-700 dark:text-slate-300">
                        {att.check_out || '—'}
                      </td>
                      <td className="px-4 py-3 text-right">
                        {userRole !== 'Employee' && (
                          <div className="flex items-center justify-end gap-1.5">
                            <button
                              onClick={() =>
                                onMarkAttendance({
                                  employee_id: att.employee_id,
                                  date: att.date,
                                  status: att.status === 'Present' ? 'Absent' : 'Present',
                                  check_in: att.status === 'Present' ? undefined : '09:00 AM',
                                  check_out: att.status === 'Present' ? undefined : '05:30 PM',
                                })
                              }
                              className="rounded-lg border border-slate-200 px-2 py-1 text-[10px] font-semibold text-slate-700 hover:bg-slate-100 dark:border-slate-700 dark:text-slate-300 dark:hover:bg-slate-800"
                            >
                              Toggle Status
                            </button>
                          </div>
                        )}
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal: Mark Attendance */}
      {showMarkModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
          <div className="relative w-full max-w-md rounded-2xl bg-white p-6 shadow-2xl dark:bg-slate-900 dark:border dark:border-slate-800">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3 dark:border-slate-800">
              <h3 className="text-base font-bold text-slate-900 dark:text-white">
                Log Attendance Punch
              </h3>
              <button
                onClick={() => setShowMarkModal(false)}
                className="rounded-lg p-1 text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="mt-4 space-y-3.5">
              <div>
                <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                  Select Employee *
                </label>
                <select
                  value={formEmployeeId}
                  onChange={(e) => setFormEmployeeId(e.target.value)}
                  className="mt-1 w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs font-medium dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                >
                  {employees.map((e) => (
                    <option key={e.id} value={e.employee_id}>
                      {e.employee_id} — {e.full_name} ({e.designation})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                  Date *
                </label>
                <input
                  type="date"
                  required
                  value={formDate}
                  onChange={(e) => setFormDate(e.target.value)}
                  className="mt-1 w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs font-medium dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                  Attendance Status *
                </label>
                <select
                  value={formStatus}
                  onChange={(e) => setFormStatus(e.target.value as Attendance['status'])}
                  className="mt-1 w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs font-medium dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                >
                  <option value="Present">Present</option>
                  <option value="Absent">Absent</option>
                  <option value="Half Day">Half Day</option>
                  <option value="On Leave">On Leave</option>
                </select>
              </div>

              {(formStatus === 'Present' || formStatus === 'Half Day') && (
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                      Check-In Time
                    </label>
                    <input
                      type="text"
                      value={formCheckIn}
                      onChange={(e) => setFormCheckIn(e.target.value)}
                      placeholder="09:00 AM"
                      className="mt-1 w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs font-mono dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                      Check-Out Time
                    </label>
                    <input
                      type="text"
                      value={formCheckOut}
                      onChange={(e) => setFormCheckOut(e.target.value)}
                      placeholder="05:30 PM"
                      className="mt-1 w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs font-mono dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                    />
                  </div>
                </div>
              )}

              <div className="mt-6 flex justify-end gap-2 border-t border-slate-100 pt-4 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowMarkModal(false)}
                  className="rounded-xl border border-slate-200 px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-50 dark:border-slate-700 dark:text-slate-300"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={saving}
                  className="rounded-xl bg-indigo-600 px-4 py-2 text-xs font-semibold text-white shadow-sm hover:bg-indigo-700 disabled:opacity-50"
                >
                  {saving ? 'Recording...' : 'Save Attendance'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
