import React, { useState } from 'react';
import {
  Search,
  Plus,
  Filter,
  Eye,
  Edit2,
  Trash2,
  Mail,
  Phone,
  Calendar,
  Briefcase,
  DollarSign,
  Download,
  LayoutGrid,
  List,
  X,
  User,
  MapPin,
  CheckCircle,
  FileSpreadsheet,
} from 'lucide-react';
import type { Employee, Department, UserRole } from '../types.ts';
import { exportToExcel, exportToPDF } from '../utils/exportUtils.ts';

interface EmployeesViewProps {
  employees: Employee[];
  departments: Department[];
  userRole: UserRole;
  onSaveEmployee: (employeeData: Partial<Employee>, isEdit: boolean) => Promise<void>;
  onDeleteEmployee: (id: string) => Promise<void>;
}

export const EmployeesView: React.FC<EmployeesViewProps> = ({
  employees,
  departments,
  userRole,
  onSaveEmployee,
  onDeleteEmployee,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedDepartment, setSelectedDepartment] = useState('all');
  const [viewMode, setViewMode] = useState<'table' | 'grid'>('table');

  // Modal States
  const [showFormModal, setShowFormModal] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [currentEmployee, setCurrentEmployee] = useState<Partial<Employee>>({});

  const [showProfileModal, setShowProfileModal] = useState(false);
  const [viewingEmployee, setViewingEmployee] = useState<Employee | null>(null);

  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [deletingId, setDeletingId] = useState<string | null>(null);

  const [saving, setSaving] = useState(false);

  // Filter logic
  const filteredEmployees = employees.filter((emp) => {
    const matchesDept = selectedDepartment === 'all' || emp.department_id === selectedDepartment;
    const q = searchQuery.toLowerCase();
    const matchesSearch =
      emp.full_name.toLowerCase().includes(q) ||
      emp.employee_id.toLowerCase().includes(q) ||
      emp.email.toLowerCase().includes(q) ||
      emp.designation.toLowerCase().includes(q);
    return matchesDept && matchesSearch;
  });

  const handleOpenAdd = () => {
    const nextId = `EMP${String(employees.length + 1).padStart(3, '0')}`;
    setCurrentEmployee({
      employee_id: nextId,
      full_name: '',
      gender: 'Male',
      dob: '1995-01-01',
      email: '',
      phone: '',
      address: '',
      department_id: departments[0]?.id || '',
      designation: '',
      joining_date: new Date().toISOString().split('T')[0],
      salary: 75000,
      photo_url: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&h=200&fit=crop&crop=faces',
      status: 'Active',
    });
    setIsEditing(false);
    setShowFormModal(true);
  };

  const handleOpenEdit = (emp: Employee) => {
    setCurrentEmployee({ ...emp });
    setIsEditing(true);
    setShowFormModal(true);
  };

  const handleOpenProfile = (emp: Employee) => {
    setViewingEmployee(emp);
    setShowProfileModal(true);
  };

  const handleSubmitForm = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentEmployee.full_name || !currentEmployee.email || !currentEmployee.employee_id) {
      alert('Please fill out all required fields.');
      return;
    }

    setSaving(true);
    try {
      await onSaveEmployee(currentEmployee, isEditing);
      setShowFormModal(false);
    } catch (err: any) {
      alert(err.message || 'Failed to save employee.');
    } finally {
      setSaving(false);
    }
  };

  const handleConfirmDelete = async () => {
    if (!deletingId) return;
    try {
      await onDeleteEmployee(deletingId);
      setShowDeleteConfirm(false);
      setDeletingId(null);
    } catch (err: any) {
      alert(err.message || 'Failed to delete employee.');
    }
  };

  const handleExportExcel = () => {
    const data = filteredEmployees.map((e) => ({
      'Employee ID': e.employee_id,
      'Full Name': e.full_name,
      Gender: e.gender,
      'Date of Birth': e.dob,
      Email: e.email,
      Phone: e.phone,
      Department: e.department_name || departments.find((d) => d.id === e.department_id)?.department_name || '',
      Designation: e.designation,
      'Joining Date': e.joining_date,
      'Annual Salary ($)': e.salary,
      Status: e.status || 'Active',
      Address: e.address,
    }));
    exportToExcel(data, `Employee_Directory_${new Date().toISOString().split('T')[0]}`);
  };

  const handleExportPDF = () => {
    const columns = [
      { header: 'ID', dataKey: 'employee_id' },
      { header: 'Full Name', dataKey: 'full_name' },
      { header: 'Email', dataKey: 'email' },
      { header: 'Department', dataKey: 'department_name' },
      { header: 'Designation', dataKey: 'designation' },
      { header: 'Salary ($)', dataKey: 'salary' },
      { header: 'Status', dataKey: 'status' },
    ];
    exportToPDF('Employee Directory Report', columns, filteredEmployees, `Employees_${new Date().toISOString().split('T')[0]}`);
  };

  // Image Upload handler (DataURL or URL)
  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        if (typeof reader.result === 'string') {
          setCurrentEmployee((prev) => ({ ...prev, photo_url: reader.result as string }));
        }
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <div className="space-y-5">
      {/* Action Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h2 className="text-xl font-bold tracking-tight text-slate-900 dark:text-white">
            Employee Directory
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Manage personnel profiles, job designations, salary baselines, and contact information.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {/* Export buttons */}
          <button
            onClick={handleExportExcel}
            className="inline-flex items-center gap-1.5 rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs font-semibold text-slate-700 shadow-sm hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-300"
            title="Export Excel"
          >
            <FileSpreadsheet className="h-3.5 w-3.5 text-emerald-600" />
            <span>Excel</span>
          </button>
          <button
            onClick={handleExportPDF}
            className="inline-flex items-center gap-1.5 rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs font-semibold text-slate-700 shadow-sm hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-300"
            title="Export PDF"
          >
            <Download className="h-3.5 w-3.5 text-rose-600" />
            <span>PDF</span>
          </button>

          {userRole !== 'Employee' && (
            <button
              onClick={handleOpenAdd}
              className="inline-flex items-center gap-1.5 rounded-xl bg-indigo-600 px-3.5 py-2 text-xs font-semibold text-white shadow-sm hover:bg-indigo-700 transition-colors"
            >
              <Plus className="h-3.5 w-3.5" />
              <span>Add Employee</span>
            </button>
          )}
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between rounded-2xl border border-slate-200 bg-white p-3 shadow-sm dark:border-slate-800 dark:bg-slate-900">
        <div className="flex flex-1 items-center gap-2 rounded-xl bg-slate-50 px-3 py-2 dark:bg-slate-800/80">
          <Search className="h-4 w-4 text-slate-400" />
          <input
            type="text"
            placeholder="Search by name, ID, email, or role..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-transparent text-xs text-slate-800 dark:text-slate-200 placeholder:text-slate-400 focus:outline-none"
          />
          {searchQuery && (
            <button onClick={() => setSearchQuery('')} className="text-slate-400 hover:text-slate-600">
              <X className="h-3.5 w-3.5" />
            </button>
          )}
        </div>

        <div className="flex items-center gap-2">
          {/* Department Filter */}
          <div className="flex items-center gap-1.5 rounded-xl border border-slate-200 bg-white px-2.5 py-1.5 dark:border-slate-700 dark:bg-slate-800">
            <Filter className="h-3.5 w-3.5 text-slate-400" />
            <select
              value={selectedDepartment}
              onChange={(e) => setSelectedDepartment(e.target.value)}
              className="bg-transparent text-xs font-medium text-slate-700 dark:text-slate-200 focus:outline-none"
            >
              <option value="all">All Departments</option>
              {departments.map((d) => (
                <option key={d.id} value={d.id}>
                  {d.department_name}
                </option>
              ))}
            </select>
          </div>

          {/* View Toggle */}
          <div className="flex rounded-xl border border-slate-200 p-0.5 dark:border-slate-700 bg-slate-50 dark:bg-slate-800">
            <button
              onClick={() => setViewMode('table')}
              className={`rounded-lg p-1.5 ${
                viewMode === 'table'
                  ? 'bg-white text-indigo-600 shadow-sm dark:bg-slate-700 dark:text-indigo-400'
                  : 'text-slate-400 hover:text-slate-600 dark:hover:text-slate-300'
              }`}
            >
              <List className="h-4 w-4" />
            </button>
            <button
              onClick={() => setViewMode('grid')}
              className={`rounded-lg p-1.5 ${
                viewMode === 'grid'
                  ? 'bg-white text-indigo-600 shadow-sm dark:bg-slate-700 dark:text-indigo-400'
                  : 'text-slate-400 hover:text-slate-600 dark:hover:text-slate-300'
              }`}
            >
              <LayoutGrid className="h-4 w-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Main List Render: Table or Grid */}
      {filteredEmployees.length === 0 ? (
        <div className="flex flex-col items-center justify-center rounded-2xl border border-dashed border-slate-200 py-16 text-center dark:border-slate-800">
          <User className="h-10 w-10 text-slate-300 dark:text-slate-600" />
          <h3 className="mt-3 text-sm font-bold text-slate-800 dark:text-slate-200">No employees found</h3>
          <p className="mt-1 text-xs text-slate-500 dark:text-slate-400 max-w-sm">
            Try adjusting your search query or department filter, or click "Add Employee" to register a new team member.
          </p>
        </div>
      ) : viewMode === 'table' ? (
        <div className="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm dark:border-slate-800 dark:bg-slate-900">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="border-b border-slate-200 bg-slate-50/75 font-bold uppercase tracking-wider text-slate-500 dark:border-slate-800 dark:bg-slate-800/50 dark:text-slate-400">
                <tr>
                  <th className="px-4 py-3.5">Employee</th>
                  <th className="px-4 py-3.5">ID</th>
                  <th className="px-4 py-3.5">Department</th>
                  <th className="px-4 py-3.5">Designation</th>
                  <th className="px-4 py-3.5">Contact</th>
                  <th className="px-4 py-3.5">Joined</th>
                  <th className="px-4 py-3.5">Annual Salary</th>
                  <th className="px-4 py-3.5">Status</th>
                  <th className="px-4 py-3.5 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {filteredEmployees.map((emp) => (
                  <tr
                    key={emp.id}
                    className="hover:bg-slate-50/80 dark:hover:bg-slate-800/50 transition-colors"
                  >
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-3">
                        <img
                          src={emp.photo_url}
                          alt={emp.full_name}
                          className="h-9 w-9 rounded-full object-cover border border-slate-200 dark:border-slate-700"
                        />
                        <div>
                          <div className="font-bold text-slate-900 dark:text-white">
                            {emp.full_name}
                          </div>
                          <div className="text-[11px] text-slate-500 dark:text-slate-400">
                            {emp.gender}
                          </div>
                        </div>
                      </div>
                    </td>
                    <td className="px-4 py-3 font-mono font-semibold text-indigo-600 dark:text-indigo-400">
                      {emp.employee_id}
                    </td>
                    <td className="px-4 py-3 font-medium text-slate-700 dark:text-slate-300">
                      {emp.department_name || departments.find((d) => d.id === emp.department_id)?.department_name || 'General'}
                    </td>
                    <td className="px-4 py-3 text-slate-700 dark:text-slate-300">
                      {emp.designation}
                    </td>
                    <td className="px-4 py-3">
                      <div className="space-y-0.5">
                        <div className="flex items-center gap-1 text-slate-600 dark:text-slate-400">
                          <Mail className="h-3 w-3 text-slate-400" />
                          <span>{emp.email}</span>
                        </div>
                        <div className="flex items-center gap-1 text-slate-500 dark:text-slate-400 text-[11px]">
                          <Phone className="h-3 w-3 text-slate-400" />
                          <span>{emp.phone}</span>
                        </div>
                      </div>
                    </td>
                    <td className="px-4 py-3 text-slate-600 dark:text-slate-400">
                      {emp.joining_date}
                    </td>
                    <td className="px-4 py-3 font-semibold text-slate-900 dark:text-white">
                      ${Number(emp.salary).toLocaleString()}
                    </td>
                    <td className="px-4 py-3">
                      <span className="inline-flex items-center rounded-full bg-emerald-50 px-2 py-0.5 text-[11px] font-bold text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-300">
                        {emp.status || 'Active'}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-right">
                      <div className="flex items-center justify-end gap-1">
                        <button
                          onClick={() => handleOpenProfile(emp)}
                          className="rounded-lg p-1.5 text-slate-500 hover:bg-slate-100 hover:text-indigo-600 dark:text-slate-400 dark:hover:bg-slate-800"
                          title="View Profile"
                        >
                          <Eye className="h-3.5 w-3.5" />
                        </button>
                        {userRole !== 'Employee' && (
                          <>
                            <button
                              onClick={() => handleOpenEdit(emp)}
                              className="rounded-lg p-1.5 text-slate-500 hover:bg-slate-100 hover:text-amber-600 dark:text-slate-400 dark:hover:bg-slate-800"
                              title="Edit Details"
                            >
                              <Edit2 className="h-3.5 w-3.5" />
                            </button>
                            <button
                              onClick={() => {
                                setDeletingId(emp.id);
                                setShowDeleteConfirm(true);
                              }}
                              className="rounded-lg p-1.5 text-slate-500 hover:bg-rose-50 hover:text-rose-600 dark:text-slate-400 dark:hover:bg-rose-950/50"
                              title="Delete Record"
                            >
                              <Trash2 className="h-3.5 w-3.5" />
                            </button>
                          </>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      ) : (
        /* Grid Mode */
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {filteredEmployees.map((emp) => (
            <div
              key={emp.id}
              className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm dark:border-slate-800 dark:bg-slate-900 transition-all hover:shadow-md"
            >
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-3">
                  <img
                    src={emp.photo_url}
                    alt={emp.full_name}
                    className="h-12 w-12 rounded-full object-cover border-2 border-indigo-100 dark:border-slate-700"
                  />
                  <div>
                    <h3 className="font-bold text-slate-900 dark:text-white">
                      {emp.full_name}
                    </h3>
                    <p className="text-xs font-semibold text-indigo-600 dark:text-indigo-400">
                      {emp.designation}
                    </p>
                    <span className="font-mono text-[10px] text-slate-400">
                      {emp.employee_id}
                    </span>
                  </div>
                </div>
                <span className="rounded-full bg-emerald-50 px-2 py-0.5 text-[10px] font-bold text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-300">
                  {emp.status || 'Active'}
                </span>
              </div>

              <div className="mt-4 space-y-1.5 border-t border-slate-100 pt-3 text-xs text-slate-600 dark:border-slate-800 dark:text-slate-300">
                <div className="flex items-center justify-between">
                  <span className="text-slate-400">Department:</span>
                  <span className="font-medium">
                    {emp.department_name || departments.find((d) => d.id === emp.department_id)?.department_name || 'General'}
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-slate-400">Email:</span>
                  <span className="truncate max-w-[170px]">{emp.email}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-slate-400">Salary:</span>
                  <span className="font-semibold text-slate-900 dark:text-white">
                    ${Number(emp.salary).toLocaleString()}/yr
                  </span>
                </div>
              </div>

              <div className="mt-4 flex items-center justify-between border-t border-slate-100 pt-3 dark:border-slate-800">
                <button
                  onClick={() => handleOpenProfile(emp)}
                  className="inline-flex items-center gap-1 text-xs font-semibold text-indigo-600 hover:text-indigo-700 dark:text-indigo-400"
                >
                  <Eye className="h-3.5 w-3.5" />
                  View Profile
                </button>

                {userRole !== 'Employee' && (
                  <div className="flex items-center gap-1">
                    <button
                      onClick={() => handleOpenEdit(emp)}
                      className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-100 hover:text-amber-600 dark:hover:bg-slate-800"
                    >
                      <Edit2 className="h-3.5 w-3.5" />
                    </button>
                    <button
                      onClick={() => {
                        setDeletingId(emp.id);
                        setShowDeleteConfirm(true);
                      }}
                      className="rounded-lg p-1.5 text-slate-400 hover:bg-rose-50 hover:text-rose-600 dark:hover:bg-rose-950/50"
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </button>
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Modal 1: Add / Edit Employee Form */}
      {showFormModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm overflow-y-auto">
          <div className="relative w-full max-w-2xl rounded-2xl bg-white p-6 shadow-2xl dark:bg-slate-900 dark:border dark:border-slate-800 my-8">
            <div className="flex items-center justify-between border-b border-slate-100 pb-4 dark:border-slate-800">
              <h3 className="text-base font-bold text-slate-900 dark:text-white">
                {isEditing ? 'Edit Employee Details' : 'Add New Employee'}
              </h3>
              <button
                onClick={() => setShowFormModal(false)}
                className="rounded-lg p-1 text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <form onSubmit={handleSubmitForm} className="mt-4 space-y-4">
              {/* Photo Upload & Preview */}
              <div className="flex items-center gap-4 rounded-xl border border-dashed border-slate-200 p-3.5 dark:border-slate-700 bg-slate-50/50 dark:bg-slate-800/40">
                <img
                  src={currentEmployee.photo_url || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&h=200&fit=crop&crop=faces'}
                  alt="Avatar preview"
                  className="h-16 w-16 rounded-full object-cover border-2 border-indigo-500 shadow-sm"
                />
                <div className="space-y-1">
                  <div className="text-xs font-bold text-slate-800 dark:text-slate-200">
                    Employee Profile Photo
                  </div>
                  <div className="flex items-center gap-2">
                    <label className="cursor-pointer rounded-lg bg-indigo-600 px-2.5 py-1 text-[11px] font-semibold text-white hover:bg-indigo-700 transition-colors">
                      Upload Image
                      <input
                        type="file"
                        accept="image/*"
                        onChange={handlePhotoUpload}
                        className="hidden"
                      />
                    </label>
                    <input
                      type="url"
                      placeholder="Or enter image URL"
                      value={currentEmployee.photo_url || ''}
                      onChange={(e) => setCurrentEmployee({ ...currentEmployee, photo_url: e.target.value })}
                      className="rounded-lg border border-slate-200 bg-white px-2 py-1 text-xs dark:border-slate-700 dark:bg-slate-800 w-64"
                    />
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                <div>
                  <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                    Employee ID *
                  </label>
                  <input
                    type="text"
                    required
                    value={currentEmployee.employee_id || ''}
                    onChange={(e) => setCurrentEmployee({ ...currentEmployee, employee_id: e.target.value })}
                    className="mt-1 w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs font-mono font-bold dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                    Full Name *
                  </label>
                  <input
                    type="text"
                    required
                    value={currentEmployee.full_name || ''}
                    onChange={(e) => setCurrentEmployee({ ...currentEmployee, full_name: e.target.value })}
                    className="mt-1 w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs font-medium dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                    Email Address *
                  </label>
                  <input
                    type="email"
                    required
                    value={currentEmployee.email || ''}
                    onChange={(e) => setCurrentEmployee({ ...currentEmployee, email: e.target.value })}
                    className="mt-1 w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs font-medium dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                    Phone Number *
                  </label>
                  <input
                    type="text"
                    required
                    value={currentEmployee.phone || ''}
                    onChange={(e) => setCurrentEmployee({ ...currentEmployee, phone: e.target.value })}
                    className="mt-1 w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs font-medium dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                    Department *
                  </label>
                  <select
                    value={currentEmployee.department_id || ''}
                    onChange={(e) => setCurrentEmployee({ ...currentEmployee, department_id: e.target.value })}
                    className="mt-1 w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs font-medium dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                  >
                    {departments.map((d) => (
                      <option key={d.id} value={d.id}>
                        {d.department_name}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                    Designation / Title *
                  </label>
                  <input
                    type="text"
                    required
                    value={currentEmployee.designation || ''}
                    onChange={(e) => setCurrentEmployee({ ...currentEmployee, designation: e.target.value })}
                    className="mt-1 w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs font-medium dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                    Gender *
                  </label>
                  <select
                    value={currentEmployee.gender || 'Male'}
                    onChange={(e) => setCurrentEmployee({ ...currentEmployee, gender: e.target.value as any })}
                    className="mt-1 w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs font-medium dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                  >
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                    <option value="Other">Other</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                    Date of Birth *
                  </label>
                  <input
                    type="date"
                    required
                    value={currentEmployee.dob || '1995-01-01'}
                    onChange={(e) => setCurrentEmployee({ ...currentEmployee, dob: e.target.value })}
                    className="mt-1 w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs font-medium dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                    Date of Joining *
                  </label>
                  <input
                    type="date"
                    required
                    value={currentEmployee.joining_date || ''}
                    onChange={(e) => setCurrentEmployee({ ...currentEmployee, joining_date: e.target.value })}
                    className="mt-1 w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs font-medium dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                    Annual Base Salary ($) *
                  </label>
                  <input
                    type="number"
                    required
                    min="0"
                    step="1000"
                    value={currentEmployee.salary ?? 75000}
                    onChange={(e) => setCurrentEmployee({ ...currentEmployee, salary: Number(e.target.value) })}
                    className="mt-1 w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs font-medium dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                  Residential Address
                </label>
                <textarea
                  rows={2}
                  value={currentEmployee.address || ''}
                  onChange={(e) => setCurrentEmployee({ ...currentEmployee, address: e.target.value })}
                  placeholder="Street address, city, state, postal code"
                  className="mt-1 w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs font-medium dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                />
              </div>

              <div className="flex items-center justify-end gap-2 border-t border-slate-100 pt-4 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowFormModal(false)}
                  className="rounded-xl border border-slate-200 px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-50 dark:border-slate-700 dark:text-slate-300"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={saving}
                  className="rounded-xl bg-indigo-600 px-5 py-2 text-xs font-semibold text-white shadow-sm hover:bg-indigo-700 disabled:opacity-50"
                >
                  {saving ? 'Saving...' : isEditing ? 'Update Employee' : 'Save Employee'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal 2: View Employee Profile */}
      {showProfileModal && viewingEmployee && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm overflow-y-auto">
          <div className="relative w-full max-w-lg rounded-2xl bg-white p-6 shadow-2xl dark:bg-slate-900 dark:border dark:border-slate-800">
            <button
              onClick={() => setShowProfileModal(false)}
              className="absolute top-5 right-5 rounded-lg p-1 text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800"
            >
              <X className="h-5 w-5" />
            </button>

            <div className="flex items-center gap-4">
              <img
                src={viewingEmployee.photo_url}
                alt={viewingEmployee.full_name}
                className="h-20 w-20 rounded-full object-cover border-4 border-indigo-100 dark:border-slate-700 shadow-md"
              />
              <div>
                <span className="font-mono text-xs font-bold text-indigo-600 dark:text-indigo-400">
                  {viewingEmployee.employee_id}
                </span>
                <h3 className="text-xl font-bold text-slate-900 dark:text-white">
                  {viewingEmployee.full_name}
                </h3>
                <p className="text-xs font-semibold text-slate-600 dark:text-slate-300">
                  {viewingEmployee.designation}
                </p>
                <span className="mt-1 inline-block rounded-full bg-emerald-100 px-2 py-0.5 text-[10px] font-bold text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300">
                  {viewingEmployee.status || 'Active'}
                </span>
              </div>
            </div>

            <div className="mt-6 space-y-2.5 rounded-xl bg-slate-50 p-4 text-xs dark:bg-slate-800/60">
              <div className="flex items-center justify-between">
                <span className="text-slate-500">Department:</span>
                <span className="font-bold text-slate-800 dark:text-white">
                  {viewingEmployee.department_name || departments.find((d) => d.id === viewingEmployee.department_id)?.department_name}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-500">Email:</span>
                <span className="font-semibold text-slate-800 dark:text-white">{viewingEmployee.email}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-500">Phone:</span>
                <span className="font-semibold text-slate-800 dark:text-white">{viewingEmployee.phone}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-500">Date of Birth:</span>
                <span className="font-semibold text-slate-800 dark:text-white">{viewingEmployee.dob}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-500">Gender:</span>
                <span className="font-semibold text-slate-800 dark:text-white">{viewingEmployee.gender}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-500">Date of Joining:</span>
                <span className="font-semibold text-slate-800 dark:text-white">{viewingEmployee.joining_date}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-500">Annual Base Salary:</span>
                <span className="font-extrabold text-indigo-600 dark:text-indigo-400">
                  ${Number(viewingEmployee.salary).toLocaleString()}
                </span>
              </div>
              <div className="flex items-start justify-between">
                <span className="text-slate-500">Address:</span>
                <span className="text-right font-medium text-slate-800 dark:text-white max-w-[220px]">
                  {viewingEmployee.address || 'Not specified'}
                </span>
              </div>
            </div>

            <div className="mt-6 flex justify-end">
              <button
                onClick={() => setShowProfileModal(false)}
                className="rounded-xl bg-indigo-600 px-4 py-2 text-xs font-semibold text-white shadow-sm hover:bg-indigo-700"
              >
                Close Profile
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Modal 3: Delete Confirmation */}
      {showDeleteConfirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
          <div className="relative w-full max-w-sm rounded-2xl bg-white p-6 shadow-2xl dark:bg-slate-900 dark:border dark:border-slate-800">
            <h3 className="text-base font-bold text-slate-900 dark:text-white">
              Delete Employee Record?
            </h3>
            <p className="mt-2 text-xs text-slate-500 dark:text-slate-400">
              Are you sure you want to permanently delete this employee? This action cannot be undone.
            </p>
            <div className="mt-6 flex justify-end gap-2">
              <button
                onClick={() => setShowDeleteConfirm(false)}
                className="rounded-xl border border-slate-200 px-3.5 py-2 text-xs font-semibold text-slate-600 dark:border-slate-700 dark:text-slate-300"
              >
                Cancel
              </button>
              <button
                onClick={handleConfirmDelete}
                className="rounded-xl bg-rose-600 px-4 py-2 text-xs font-semibold text-white shadow-sm hover:bg-rose-700"
              >
                Confirm Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
