import React, { useState } from 'react';
import {
  Award,
  Star,
  Plus,
  Trash2,
  CheckCircle2,
  FileSpreadsheet,
  Download,
  X,
  UserCheck,
  Calendar,
  Sparkles,
} from 'lucide-react';
import type { Performance, Employee, UserRole } from '../types.ts';
import { exportToExcel, exportToPDF } from '../utils/exportUtils.ts';

interface PerformanceViewProps {
  performance: Performance[];
  employees: Employee[];
  userRole: UserRole;
  onCreateReview: (data: Partial<Performance>) => Promise<void>;
  onDeleteReview: (id: string) => Promise<void>;
}

export const PerformanceView: React.FC<PerformanceViewProps> = ({
  performance,
  employees,
  userRole,
  onCreateReview,
  onDeleteReview,
}) => {
  const [showModal, setShowModal] = useState(false);
  const [formEmployeeId, setFormEmployeeId] = useState(employees[0]?.employee_id || '');
  const [formRating, setFormRating] = useState<number>(5);
  const [formAchievements, setFormAchievements] = useState('');
  const [formFeedback, setFormFeedback] = useState('');
  const [formReviewer, setFormReviewer] = useState('Sarah Jenkins (VP Eng)');
  const [saving, setSaving] = useState(false);

  const averageRating =
    performance.length > 0
      ? (performance.reduce((sum, p) => sum + p.rating, 0) / performance.length).toFixed(1)
      : '0.0';

  const fiveStarCount = performance.filter((p) => p.rating === 5).length;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formFeedback) {
      alert('Please provide detailed feedback.');
      return;
    }
    setSaving(true);
    try {
      await onCreateReview({
        employee_id: formEmployeeId,
        rating: formRating,
        achievements: formAchievements,
        feedback: formFeedback,
        reviewer_name: formReviewer,
      });
      setShowModal(false);
      setFormAchievements('');
      setFormFeedback('');
    } catch (err: any) {
      alert(err.message || 'Failed to submit appraisal.');
    } finally {
      setSaving(false);
    }
  };

  const handleExportExcel = () => {
    const data = performance.map((p) => ({
      'Employee ID': p.employee_id,
      'Employee Name': p.employee_name || employees.find((e) => e.employee_id === p.employee_id)?.full_name || p.employee_id,
      'Rating (1-5)': p.rating,
      Achievements: p.achievements,
      Feedback: p.feedback,
      'Review Date': p.review_date,
      Reviewer: p.reviewer_name || 'Management',
    }));
    exportToExcel(data, `Performance_Reviews_${new Date().toISOString().split('T')[0]}`);
  };

  const handleExportPDF = () => {
    const columns = [
      { header: 'Employee', dataKey: 'employee_name' },
      { header: 'Rating', dataKey: 'rating' },
      { header: 'Key Achievements', dataKey: 'achievements' },
      { header: 'Feedback', dataKey: 'feedback' },
      { header: 'Reviewer', dataKey: 'reviewer_name' },
      { header: 'Date', dataKey: 'review_date' },
    ];
    exportToPDF('Performance Appraisals Report', columns, performance, `Performance_${new Date().toISOString().split('T')[0]}`);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h2 className="text-xl font-bold tracking-tight text-slate-900 dark:text-white">
            Performance Management
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Conduct 360-degree staff appraisals, record milestone achievements, and assign calibrated performance ratings.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={handleExportExcel}
            className="inline-flex items-center gap-1.5 rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs font-semibold text-slate-700 shadow-sm hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-300"
          >
            <FileSpreadsheet className="h-3.5 w-3.5 text-emerald-600" />
            <span>Excel</span>
          </button>
          <button
            onClick={handleExportPDF}
            className="inline-flex items-center gap-1.5 rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs font-semibold text-slate-700 shadow-sm hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-300"
          >
            <Download className="h-3.5 w-3.5 text-rose-600" />
            <span>PDF</span>
          </button>

          {userRole !== 'Employee' && (
            <button
              onClick={() => setShowModal(true)}
              className="inline-flex items-center gap-1.5 rounded-xl bg-indigo-600 px-3.5 py-2 text-xs font-semibold text-white shadow-sm hover:bg-indigo-700 transition-colors"
            >
              <Plus className="h-3.5 w-3.5" />
              <span>Record Appraisal</span>
            </button>
          )}
        </div>
      </div>

      {/* KPI Stats */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
        <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm dark:border-slate-800 dark:bg-slate-900">
          <div className="text-xs font-bold uppercase tracking-wider text-slate-400">
            Average Organization Rating
          </div>
          <div className="mt-2 flex items-center gap-2">
            <span className="text-3xl font-extrabold text-slate-900 dark:text-white">
              {averageRating}
            </span>
            <div className="flex items-center text-amber-400">
              {[1, 2, 3, 4, 5].map((s) => (
                <Star
                  key={s}
                  className={`h-4 w-4 ${s <= Math.round(Number(averageRating)) ? 'fill-amber-400' : 'text-slate-200 dark:text-slate-700'}`}
                />
              ))}
            </div>
          </div>
          <p className="mt-1 text-[11px] text-slate-500">Across all completed review cycles</p>
        </div>

        <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm dark:border-slate-800 dark:bg-slate-900">
          <div className="text-xs font-bold uppercase tracking-wider text-emerald-600">
            Top Tier (5 Stars)
          </div>
          <div className="mt-2 text-3xl font-extrabold text-emerald-600">
            {fiveStarCount} Staff
          </div>
          <p className="mt-1 text-[11px] text-slate-500">Exceptional rating recipients this cycle</p>
        </div>

        <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm dark:border-slate-800 dark:bg-slate-900">
          <div className="text-xs font-bold uppercase tracking-wider text-indigo-600">
            Total Evaluations
          </div>
          <div className="mt-2 text-3xl font-extrabold text-indigo-600">
            {performance.length} Recorded
          </div>
          <p className="mt-1 text-[11px] text-slate-500">Archived in official personnel records</p>
        </div>
      </div>

      {/* Performance Reviews Grid */}
      <div className="grid grid-cols-1 gap-5 md:grid-cols-2">
        {performance.map((perf) => {
          const emp = employees.find((e) => e.employee_id === perf.employee_id);
          return (
            <div
              key={perf.id}
              className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm dark:border-slate-800 dark:bg-slate-900 flex flex-col justify-between hover:shadow-md transition-all"
            >
              <div>
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-3">
                    <img
                      src={emp?.photo_url || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&h=100&fit=crop&crop=faces'}
                      alt={emp?.full_name || perf.employee_id}
                      className="h-11 w-11 rounded-full object-cover border-2 border-indigo-100 dark:border-slate-700"
                    />
                    <div>
                      <h3 className="font-bold text-slate-900 dark:text-white text-sm">
                        {emp?.full_name || perf.employee_name || perf.employee_id}
                      </h3>
                      <p className="text-xs text-indigo-600 dark:text-indigo-400 font-medium">
                        {emp?.designation || perf.designation || 'Staff'}
                      </p>
                      <span className="font-mono text-[10px] text-slate-400">
                        {perf.employee_id}
                      </span>
                    </div>
                  </div>

                  <div className="flex flex-col items-end gap-1">
                    <div className="flex items-center gap-0.5">
                      {[1, 2, 3, 4, 5].map((star) => (
                        <Star
                          key={star}
                          className={`h-4 w-4 ${
                            star <= perf.rating
                              ? 'fill-amber-400 text-amber-400'
                              : 'text-slate-200 dark:text-slate-700'
                          }`}
                        />
                      ))}
                    </div>
                    <span className="text-[10px] font-bold text-slate-500">
                      {perf.rating}.0 / 5.0 Rating
                    </span>
                  </div>
                </div>

                {/* Achievements Box */}
                {perf.achievements && (
                  <div className="mt-4 rounded-xl bg-amber-50/60 p-3 text-xs dark:bg-amber-950/30 border border-amber-100 dark:border-amber-900/40">
                    <div className="flex items-center gap-1.5 font-bold text-amber-900 dark:text-amber-200">
                      <Sparkles className="h-3.5 w-3.5 text-amber-500" />
                      <span>Key Achievements & Milestones</span>
                    </div>
                    <p className="mt-1 text-slate-700 dark:text-slate-300 leading-relaxed">
                      {perf.achievements}
                    </p>
                  </div>
                )}

                {/* Supervisor Feedback */}
                <div className="mt-3 text-xs space-y-1">
                  <span className="font-bold uppercase tracking-wider text-[10px] text-slate-400">
                    Manager Review & Feedback:
                  </span>
                  <p className="text-slate-700 dark:text-slate-300 italic leading-relaxed">
                    "{perf.feedback}"
                  </p>
                </div>
              </div>

              <div className="mt-6 flex items-center justify-between border-t border-slate-100 pt-3 dark:border-slate-800 text-[11px] text-slate-400">
                <div className="flex items-center gap-1.5">
                  <UserCheck className="h-3.5 w-3.5 text-indigo-500" />
                  <span>Reviewer: {perf.reviewer_name || 'Management'}</span>
                </div>

                <div className="flex items-center gap-2">
                  <span>{perf.review_date}</span>
                  {userRole !== 'Employee' && (
                    <button
                      onClick={() => {
                        if (confirm('Delete this evaluation record?')) {
                          onDeleteReview(perf.id);
                        }
                      }}
                      className="rounded p-1 text-slate-400 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40"
                      title="Delete Review"
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </button>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Modal: Record Appraisal */}
      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
          <div className="relative w-full max-w-md rounded-2xl bg-white p-6 shadow-2xl dark:bg-slate-900 dark:border dark:border-slate-800">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3 dark:border-slate-800">
              <h3 className="text-base font-bold text-slate-900 dark:text-white">
                Record Employee Appraisal
              </h3>
              <button
                onClick={() => setShowModal(false)}
                className="rounded-lg p-1 text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="mt-4 space-y-3.5">
              <div>
                <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                  Select Employee *
                </label>
                <select
                  value={formEmployeeId}
                  onChange={(e) => setFormEmployeeId(e.target.value)}
                  className="mt-1 w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs font-medium dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                >
                  {employees.map((e) => (
                    <option key={e.id} value={e.employee_id}>
                      {e.employee_id} — {e.full_name} ({e.designation})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                  Performance Rating (1 to 5 Stars) *
                </label>
                <div className="mt-1.5 flex items-center gap-2">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <button
                      key={star}
                      type="button"
                      onClick={() => setFormRating(star)}
                      className="p-1 text-amber-400 hover:scale-125 transition-transform"
                    >
                      <Star
                        className={`h-6 w-6 ${
                          star <= formRating ? 'fill-amber-400' : 'text-slate-300 dark:text-slate-600'
                        }`}
                      />
                    </button>
                  ))}
                  <span className="text-xs font-bold text-slate-700 dark:text-slate-300 ml-2">
                    {formRating} Star{formRating > 1 ? 's' : ''}
                  </span>
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                  Key Achievements & Project Deliverables
                </label>
                <textarea
                  rows={2}
                  value={formAchievements}
                  onChange={(e) => setFormAchievements(e.target.value)}
                  placeholder="Key contributions, shipped features, efficiency gains..."
                  className="mt-1 w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs font-medium dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                  Manager Feedback & Improvement Areas *
                </label>
                <textarea
                  required
                  rows={3}
                  value={formFeedback}
                  onChange={(e) => setFormFeedback(e.target.value)}
                  placeholder="Detailed qualitative feedback, strengths, and mentorship notes..."
                  className="mt-1 w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs font-medium dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                  Reviewer Name & Designation
                </label>
                <input
                  type="text"
                  value={formReviewer}
                  onChange={(e) => setFormReviewer(e.target.value)}
                  className="mt-1 w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs font-medium dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                />
              </div>

              <div className="mt-6 flex justify-end gap-2 border-t border-slate-100 pt-4 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowModal(false)}
                  className="rounded-xl border border-slate-200 px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-50 dark:border-slate-700 dark:text-slate-300"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={saving}
                  className="rounded-xl bg-indigo-600 px-4 py-2 text-xs font-semibold text-white shadow-sm hover:bg-indigo-700 disabled:opacity-50"
                >
                  {saving ? 'Saving...' : 'Save Evaluation'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
