import React, { useState } from 'react';
import {
  FileSpreadsheet,
  Download,
  Users,
  CalendarCheck2,
  Wallet,
  Building2,
  CalendarOff,
  Filter,
  CheckCircle2,
} from 'lucide-react';
import type { Employee, Department, Attendance, Leave, SalaryRecord } from '../types.ts';
import { exportToExcel, exportToPDF } from '../utils/exportUtils.ts';

interface ReportsViewProps {
  employees: Employee[];
  departments: Department[];
  attendance: Attendance[];
  leaves: Leave[];
  salaries: SalaryRecord[];
}

type ReportType = 'employees' | 'attendance' | 'salaries' | 'departments' | 'leaves';

export const ReportsView: React.FC<ReportsViewProps> = ({
  employees,
  departments,
  attendance,
  leaves,
  salaries,
}) => {
  const [reportType, setReportType] = useState<ReportType>('employees');

  const reportTypes = [
    { id: 'employees' as ReportType, title: 'Employee Directory', icon: Users, count: employees.length, desc: 'Complete staff roster, contact, designation, and salary' },
    { id: 'attendance' as ReportType, title: 'Attendance Log', icon: CalendarCheck2, count: attendance.length, desc: 'Punches, timestamps, presence, and absence logs' },
    { id: 'salaries' as ReportType, title: 'Salary & Payroll', icon: Wallet, count: salaries.length, desc: 'Gross base, allowances, deductions, and net payment' },
    { id: 'departments' as ReportType, title: 'Department Divisions', icon: Building2, count: departments.length, desc: 'Department heads, team member counts, and descriptions' },
    { id: 'leaves' as ReportType, title: 'Time Off & Leaves', icon: CalendarOff, count: leaves.length, desc: 'Vacation, sick leaves, duration, and approvals' },
  ];

  const handleExportExcel = () => {
    const today = new Date().toISOString().split('T')[0];
    switch (reportType) {
      case 'employees': {
        const data = employees.map((e) => ({
          'Employee ID': e.employee_id,
          'Full Name': e.full_name,
          Email: e.email,
          Phone: e.phone,
          Department: e.department_name || departments.find((d) => d.id === e.department_id)?.department_name || '',
          Designation: e.designation,
          'Annual Salary ($)': e.salary,
          'Joining Date': e.joining_date,
          Status: e.status || 'Active',
        }));
        exportToExcel(data, `Employee_Report_${today}`);
        break;
      }
      case 'attendance': {
        const data = attendance.map((a) => ({
          Date: a.date,
          'Employee ID': a.employee_id,
          'Employee Name': a.employee_name || a.employee_id,
          Status: a.status,
          'Check In': a.check_in || 'N/A',
          'Check Out': a.check_out || 'N/A',
        }));
        exportToExcel(data, `Attendance_Report_${today}`);
        break;
      }
      case 'salaries': {
        const data = salaries.map((s) => ({
          Cycle: s.month_year,
          'Employee ID': s.employee_id,
          'Employee Name': s.employee_name || s.employee_id,
          'Basic ($)': s.basic_salary,
          'Allowances ($)': s.allowances,
          'Deductions ($)': s.deductions,
          'Net Salary ($)': s.net_salary,
          'Disbursal Date': s.payment_date,
          Status: s.payment_status,
        }));
        exportToExcel(data, `Salary_Report_${today}`);
        break;
      }
      case 'departments': {
        const data = departments.map((d) => ({
          'Department ID': d.id,
          'Department Name': d.department_name,
          'Department Head': d.department_head,
          'Total Staff': employees.filter((e) => e.department_id === d.id).length,
          Description: d.description,
        }));
        exportToExcel(data, `Department_Report_${today}`);
        break;
      }
      case 'leaves': {
        const data = leaves.map((l) => ({
          'Employee ID': l.employee_id,
          'Employee Name': l.employee_name || l.employee_id,
          Category: l.leave_type,
          'Start Date': l.start_date,
          'End Date': l.end_date,
          Days: l.days_count,
          Reason: l.reason,
          Status: l.status,
          'Approved By': l.approved_by || 'Pending',
        }));
        exportToExcel(data, `Leave_Report_${today}`);
        break;
      }
    }
  };

  const handleExportPDF = () => {
    const today = new Date().toISOString().split('T')[0];
    switch (reportType) {
      case 'employees': {
        const cols = [
          { header: 'ID', dataKey: 'employee_id' },
          { header: 'Name', dataKey: 'full_name' },
          { header: 'Email', dataKey: 'email' },
          { header: 'Department', dataKey: 'department_name' },
          { header: 'Role', dataKey: 'designation' },
          { header: 'Salary ($)', dataKey: 'salary' },
        ];
        exportToPDF('Comprehensive Employee Directory', cols, employees, `Employee_Report_${today}`);
        break;
      }
      case 'attendance': {
        const cols = [
          { header: 'Date', dataKey: 'date' },
          { header: 'ID', dataKey: 'employee_id' },
          { header: 'Name', dataKey: 'employee_name' },
          { header: 'Status', dataKey: 'status' },
          { header: 'Check In', dataKey: 'check_in' },
          { header: 'Check Out', dataKey: 'check_out' },
        ];
        exportToPDF('Consolidated Attendance Record', cols, attendance, `Attendance_Report_${today}`);
        break;
      }
      case 'salaries': {
        const cols = [
          { header: 'Cycle', dataKey: 'month_year' },
          { header: 'Employee', dataKey: 'employee_name' },
          { header: 'Basic ($)', dataKey: 'basic_salary' },
          { header: 'Allowances ($)', dataKey: 'allowances' },
          { header: 'Deductions ($)', dataKey: 'deductions' },
          { header: 'Net Pay ($)', dataKey: 'net_salary' },
        ];
        exportToPDF('Payroll & Salary Disbursal Report', cols, salaries, `Salary_Report_${today}`);
        break;
      }
      case 'departments': {
        const cols = [
          { header: 'Department', dataKey: 'department_name' },
          { header: 'Head / Director', dataKey: 'department_head' },
          { header: 'Description', dataKey: 'description' },
        ];
        exportToPDF('Department Roster & Structure', cols, departments, `Department_Report_${today}`);
        break;
      }
      case 'leaves': {
        const cols = [
          { header: 'Employee', dataKey: 'employee_name' },
          { header: 'Type', dataKey: 'leave_type' },
          { header: 'Start', dataKey: 'start_date' },
          { header: 'End', dataKey: 'end_date' },
          { header: 'Days', dataKey: 'days_count' },
          { header: 'Status', dataKey: 'status' },
        ];
        exportToPDF('Leave & Absence Ledger', cols, leaves, `Leave_Report_${today}`);
        break;
      }
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h2 className="text-xl font-bold tracking-tight text-slate-900 dark:text-white">
            Reports & Data Export Center
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Generate audit-ready organizational summaries and export instant Excel spreadsheets and PDF files.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleExportExcel}
            className="inline-flex items-center gap-1.5 rounded-xl bg-emerald-600 px-4 py-2 text-xs font-semibold text-white shadow-sm hover:bg-emerald-700 transition-colors"
          >
            <FileSpreadsheet className="h-4 w-4" />
            <span>Export to Excel (.xlsx)</span>
          </button>
          <button
            onClick={handleExportPDF}
            className="inline-flex items-center gap-1.5 rounded-xl bg-rose-600 px-4 py-2 text-xs font-semibold text-white shadow-sm hover:bg-rose-700 transition-colors"
          >
            <Download className="h-4 w-4" />
            <span>Export to PDF</span>
          </button>
        </div>
      </div>

      {/* Report Selector Cards */}
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-5">
        {reportTypes.map((rt) => {
          const Icon = rt.icon;
          const isSelected = reportType === rt.id;
          return (
            <button
              key={rt.id}
              onClick={() => setReportType(rt.id)}
              className={`flex flex-col items-start rounded-2xl p-4 text-left transition-all border ${
                isSelected
                  ? 'border-indigo-600 bg-indigo-50/50 shadow-sm dark:border-indigo-500 dark:bg-indigo-950/40'
                  : 'border-slate-200 bg-white hover:border-slate-300 dark:border-slate-800 dark:bg-slate-900'
              }`}
            >
              <div
                className={`rounded-xl p-2 ${
                  isSelected
                    ? 'bg-indigo-600 text-white'
                    : 'bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-400'
                }`}
              >
                <Icon className="h-4 w-4" />
              </div>
              <span className="mt-3 text-xs font-bold text-slate-900 dark:text-white">
                {rt.title}
              </span>
              <span className="mt-0.5 text-[11px] text-slate-500">
                {rt.count} Records
              </span>
            </button>
          );
        })}
      </div>

      {/* Report Preview Table */}
      <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm dark:border-slate-800 dark:bg-slate-900">
        <div className="flex items-center justify-between border-b border-slate-100 pb-3 dark:border-slate-800">
          <div>
            <h3 className="text-sm font-bold text-slate-900 dark:text-white capitalize">
              Live Preview: {reportType} Report
            </h3>
            <p className="text-[11px] text-slate-500">
              Interactive snapshot of records ready for document export.
            </p>
          </div>
          <span className="rounded-full bg-indigo-100 px-2.5 py-0.5 text-[11px] font-bold text-indigo-700 dark:bg-indigo-950 dark:text-indigo-300">
            Validated Data Source
          </span>
        </div>

        <div className="mt-4 overflow-x-auto max-h-96">
          <table className="w-full text-left text-xs">
            <thead className="border-b border-slate-200 bg-slate-50/75 font-bold uppercase tracking-wider text-slate-500 dark:border-slate-800 dark:bg-slate-800/50 dark:text-slate-400 sticky top-0">
              <tr>
                {reportType === 'employees' && (
                  <>
                    <th className="px-3 py-2.5">ID</th>
                    <th className="px-3 py-2.5">Full Name</th>
                    <th className="px-3 py-2.5">Email</th>
                    <th className="px-3 py-2.5">Department</th>
                    <th className="px-3 py-2.5">Role</th>
                    <th className="px-3 py-2.5">Salary</th>
                  </>
                )}
                {reportType === 'attendance' && (
                  <>
                    <th className="px-3 py-2.5">Date</th>
                    <th className="px-3 py-2.5">Employee ID</th>
                    <th className="px-3 py-2.5">Employee Name</th>
                    <th className="px-3 py-2.5">Status</th>
                    <th className="px-3 py-2.5">Check In</th>
                    <th className="px-3 py-2.5">Check Out</th>
                  </>
                )}
                {reportType === 'salaries' && (
                  <>
                    <th className="px-3 py-2.5">Month/Year</th>
                    <th className="px-3 py-2.5">Employee</th>
                    <th className="px-3 py-2.5">Basic</th>
                    <th className="px-3 py-2.5">Allowances</th>
                    <th className="px-3 py-2.5">Deductions</th>
                    <th className="px-3 py-2.5">Net Salary</th>
                  </>
                )}
                {reportType === 'departments' && (
                  <>
                    <th className="px-3 py-2.5">Department</th>
                    <th className="px-3 py-2.5">Head</th>
                    <th className="px-3 py-2.5">Members</th>
                    <th className="px-3 py-2.5">Description</th>
                  </>
                )}
                {reportType === 'leaves' && (
                  <>
                    <th className="px-3 py-2.5">Employee</th>
                    <th className="px-3 py-2.5">Type</th>
                    <th className="px-3 py-2.5">Start Date</th>
                    <th className="px-3 py-2.5">End Date</th>
                    <th className="px-3 py-2.5">Days</th>
                    <th className="px-3 py-2.5">Status</th>
                  </>
                )}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {reportType === 'employees' &&
                employees.map((e) => (
                  <tr key={e.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/50">
                    <td className="px-3 py-2 font-mono font-bold text-indigo-600 dark:text-indigo-400">{e.employee_id}</td>
                    <td className="px-3 py-2 font-semibold text-slate-800 dark:text-slate-200">{e.full_name}</td>
                    <td className="px-3 py-2 text-slate-600 dark:text-slate-400">{e.email}</td>
                    <td className="px-3 py-2 text-slate-600 dark:text-slate-400">{e.department_name}</td>
                    <td className="px-3 py-2 text-slate-600 dark:text-slate-400">{e.designation}</td>
                    <td className="px-3 py-2 font-mono font-semibold">${Number(e.salary).toLocaleString()}</td>
                  </tr>
                ))}

              {reportType === 'attendance' &&
                attendance.map((a) => (
                  <tr key={a.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/50">
                    <td className="px-3 py-2 font-medium text-slate-700 dark:text-slate-300">{a.date}</td>
                    <td className="px-3 py-2 font-mono text-indigo-600 dark:text-indigo-400">{a.employee_id}</td>
                    <td className="px-3 py-2 font-semibold text-slate-800 dark:text-slate-200">{a.employee_name || a.employee_id}</td>
                    <td className="px-3 py-2 font-bold">{a.status}</td>
                    <td className="px-3 py-2 font-mono text-slate-600">{a.check_in || '—'}</td>
                    <td className="px-3 py-2 font-mono text-slate-600">{a.check_out || '—'}</td>
                  </tr>
                ))}

              {reportType === 'salaries' &&
                salaries.map((s) => (
                  <tr key={s.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/50">
                    <td className="px-3 py-2 font-semibold text-slate-700 dark:text-slate-300">{s.month_year}</td>
                    <td className="px-3 py-2 font-semibold text-slate-800 dark:text-slate-200">{s.employee_name}</td>
                    <td className="px-3 py-2 font-mono">${Number(s.basic_salary).toLocaleString()}</td>
                    <td className="px-3 py-2 font-mono text-emerald-600">+${Number(s.allowances).toLocaleString()}</td>
                    <td className="px-3 py-2 font-mono text-rose-600">-${Number(s.deductions).toLocaleString()}</td>
                    <td className="px-3 py-2 font-mono font-bold">${Number(s.net_salary).toLocaleString()}</td>
                  </tr>
                ))}

              {reportType === 'departments' &&
                departments.map((d) => (
                  <tr key={d.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/50">
                    <td className="px-3 py-2 font-bold text-slate-800 dark:text-slate-200">{d.department_name}</td>
                    <td className="px-3 py-2 text-slate-700 dark:text-slate-300">{d.department_head}</td>
                    <td className="px-3 py-2 font-bold text-indigo-600">{employees.filter((e) => e.department_id === d.id).length}</td>
                    <td className="px-3 py-2 text-slate-500 max-w-sm truncate">{d.description}</td>
                  </tr>
                ))}

              {reportType === 'leaves' &&
                leaves.map((l) => (
                  <tr key={l.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/50">
                    <td className="px-3 py-2 font-semibold text-slate-800 dark:text-slate-200">{l.employee_name || l.employee_id}</td>
                    <td className="px-3 py-2 text-slate-700 dark:text-slate-300">{l.leave_type}</td>
                    <td className="px-3 py-2 text-slate-600">{l.start_date}</td>
                    <td className="px-3 py-2 text-slate-600">{l.end_date}</td>
                    <td className="px-3 py-2 font-bold text-indigo-600">{l.days_count}</td>
                    <td className="px-3 py-2 font-bold">{l.status}</td>
                  </tr>
                ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
