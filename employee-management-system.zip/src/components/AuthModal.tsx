import React, { useState } from 'react';
import {
  ShieldCheck,
  Lock,
  Mail,
  UserCheck,
  Briefcase,
  ArrowRight,
  KeyRound,
  CheckCircle2,
  X,
  AlertCircle,
} from 'lucide-react';
import type { UserRole, UserSession } from '../types.ts';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  onLoginSuccess: (user: UserSession) => void;
}

export const AuthModal: React.FC<AuthModalProps> = ({ isOpen, onClose, onLoginSuccess }) => {
  const [mode, setMode] = useState<'login' | 'forgot'>('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [role, setRole] = useState<UserRole>('Admin');
  const [resetEmail, setResetEmail] = useState('');
  const [resetSent, setResetSent] = useState(false);
  const [error, setError] = useState('');

  if (!isOpen) return null;

  const handleQuickLogin = (demoRole: UserRole) => {
    let name = 'Alexander Wright';
    let mail = 'admin@enterprise.org';
    let empId = 'EMP001';

    if (demoRole === 'HR Manager') {
      name = 'Sarah Jenkins';
      mail = 'sarah.j@enterprise.org';
      empId = 'EMP002';
    } else if (demoRole === 'Employee') {
      name = 'Michael Chen';
      mail = 'm.chen@enterprise.org';
      empId = 'EMP003';
    }

    onLoginSuccess({
      id: `usr_${Date.now()}`,
      full_name: name,
      email: mail,
      role: demoRole,
      employee_id: empId,
      avatar: `https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&h=100&fit=crop&crop=faces`,
    });
    onClose();
  };

  const handleCustomLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password) {
      setError('Please provide your email and password.');
      return;
    }
    setError('');

    // Generate authenticated session
    onLoginSuccess({
      id: `usr_${Date.now()}`,
      full_name: email.split('@')[0].replace('.', ' ').toUpperCase(),
      email,
      role,
      employee_id: 'EMP001',
      avatar: `https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop&crop=faces`,
    });
    onClose();
  };

  const handleForgotSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!resetEmail) {
      setError('Please enter your registered enterprise email.');
      return;
    }
    setResetSent(true);
    setError('');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-md">
      <div className="relative w-full max-w-md rounded-2xl border border-slate-200 bg-white p-6 shadow-2xl dark:border-slate-800 dark:bg-slate-900">
        <button
          onClick={onClose}
          className="absolute right-4 top-4 rounded-lg p-1 text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800"
        >
          <X className="h-5 w-5" />
        </button>

        {mode === 'login' ? (
          <div>
            <div className="text-center">
              <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-2xl bg-indigo-600 text-white shadow-lg shadow-indigo-500/25">
                <ShieldCheck className="h-6 w-6" />
              </div>
              <h3 className="mt-3 text-lg font-bold text-slate-900 dark:text-white">
                Enterprise Portal Login
              </h3>
              <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
                Sign in with Role-Based Access Control credentials
              </p>
            </div>

            {/* Quick Demo Switcher Buttons */}
            <div className="mt-5">
              <span className="block text-center text-[10px] font-bold uppercase tracking-wider text-slate-400">
                1-Click Role Access (Demo Presets)
              </span>
              <div className="mt-2 grid grid-cols-3 gap-2">
                <button
                  type="button"
                  onClick={() => handleQuickLogin('Admin')}
                  className="flex flex-col items-center rounded-xl border border-indigo-200 bg-indigo-50/50 p-2 text-center text-xs font-bold text-indigo-700 hover:bg-indigo-100 dark:border-indigo-800 dark:bg-indigo-950/40 dark:text-indigo-300 transition-colors"
                >
                  <ShieldCheck className="h-4 w-4 mb-1" />
                  <span>Admin</span>
                  <span className="text-[9px] font-normal text-slate-500">Full Control</span>
                </button>
                <button
                  type="button"
                  onClick={() => handleQuickLogin('HR Manager')}
                  className="flex flex-col items-center rounded-xl border border-purple-200 bg-purple-50/50 p-2 text-center text-xs font-bold text-purple-700 hover:bg-purple-100 dark:border-purple-800 dark:bg-purple-950/40 dark:text-purple-300 transition-colors"
                >
                  <UserCheck className="h-4 w-4 mb-1" />
                  <span>HR Manager</span>
                  <span className="text-[9px] font-normal text-slate-500">Staff & Payroll</span>
                </button>
                <button
                  type="button"
                  onClick={() => handleQuickLogin('Employee')}
                  className="flex flex-col items-center rounded-xl border border-emerald-200 bg-emerald-50/50 p-2 text-center text-xs font-bold text-emerald-700 hover:bg-emerald-100 dark:border-emerald-800 dark:bg-emerald-950/40 dark:text-emerald-300 transition-colors"
                >
                  <Briefcase className="h-4 w-4 mb-1" />
                  <span>Employee</span>
                  <span className="text-[9px] font-normal text-slate-500">Self Service</span>
                </button>
              </div>
            </div>

            <div className="relative my-4 flex items-center justify-center">
              <div className="w-full border-t border-slate-200 dark:border-slate-800" />
              <span className="bg-white px-3 text-[10px] font-bold uppercase tracking-wider text-slate-400 dark:bg-slate-900">
                Or Custom Credentials
              </span>
            </div>

            {error && (
              <div className="mb-3 flex items-center gap-2 rounded-xl bg-rose-50 p-2.5 text-xs text-rose-700 dark:bg-rose-950/50 dark:text-rose-300">
                <AlertCircle className="h-4 w-4 shrink-0" />
                <span>{error}</span>
              </div>
            )}

            <form onSubmit={handleCustomLogin} className="space-y-3">
              <div>
                <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                  Select Role
                </label>
                <select
                  value={role}
                  onChange={(e) => setRole(e.target.value as UserRole)}
                  className="mt-1 w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs font-medium dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                >
                  <option value="Admin">Admin (Full System Control)</option>
                  <option value="HR Manager">HR Manager (HR & Payroll)</option>
                  <option value="Employee">Employee (Self-Service View)</option>
                </select>
              </div>

              <div>
                <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                  Email Address
                </label>
                <div className="relative mt-1">
                  <Mail className="pointer-events-none absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="user@enterprise.org"
                    className="w-full rounded-xl border border-slate-200 bg-white pl-9 pr-3 py-2 text-xs font-medium dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                  />
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between">
                  <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                    Password
                  </label>
                  <button
                    type="button"
                    onClick={() => {
                      setMode('forgot');
                      setError('');
                    }}
                    className="text-[11px] font-semibold text-indigo-600 hover:underline dark:text-indigo-400"
                  >
                    Forgot Password?
                  </button>
                </div>
                <div className="relative mt-1">
                  <Lock className="pointer-events-none absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
                  <input
                    type="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••••••"
                    className="w-full rounded-xl border border-slate-200 bg-white pl-9 pr-3 py-2 text-xs font-medium dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                  />
                </div>
              </div>

              <button
                type="submit"
                className="mt-4 flex w-full items-center justify-center gap-2 rounded-xl bg-indigo-600 py-2.5 text-xs font-bold text-white shadow-sm hover:bg-indigo-700 transition-colors"
              >
                <span>Sign In to System</span>
                <ArrowRight className="h-4 w-4" />
              </button>
            </form>
          </div>
        ) : (
          <div>
            <div className="text-center">
              <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-2xl bg-amber-500 text-white shadow-lg shadow-amber-500/25">
                <KeyRound className="h-6 w-6" />
              </div>
              <h3 className="mt-3 text-lg font-bold text-slate-900 dark:text-white">
                Password Recovery
              </h3>
              <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
                Enter your work email to receive password reset instructions
              </p>
            </div>

            {resetSent ? (
              <div className="mt-5 rounded-2xl bg-emerald-50 p-4 text-center dark:bg-emerald-950/50">
                <CheckCircle2 className="mx-auto h-8 w-8 text-emerald-600" />
                <h4 className="mt-2 text-xs font-bold text-emerald-800 dark:text-emerald-200">
                  Instructions Dispatched!
                </h4>
                <p className="mt-1 text-[11px] text-emerald-700 dark:text-emerald-300">
                  A reset link has been dispatched to <b>{resetEmail}</b>. Please follow the instructions to set your new password.
                </p>
                <button
                  type="button"
                  onClick={() => {
                    setMode('login');
                    setResetSent(false);
                  }}
                  className="mt-4 inline-flex items-center gap-1 rounded-xl bg-emerald-600 px-4 py-2 text-xs font-bold text-white hover:bg-emerald-700"
                >
                  Back to Sign In
                </button>
              </div>
            ) : (
              <form onSubmit={handleForgotSubmit} className="mt-5 space-y-3">
                {error && (
                  <div className="flex items-center gap-2 rounded-xl bg-rose-50 p-2.5 text-xs text-rose-700">
                    <AlertCircle className="h-4 w-4 shrink-0" />
                    <span>{error}</span>
                  </div>
                )}
                <div>
                  <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                    Registered Corporate Email
                  </label>
                  <input
                    type="email"
                    required
                    value={resetEmail}
                    onChange={(e) => setResetEmail(e.target.value)}
                    placeholder="name@enterprise.org"
                    className="mt-1 w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs font-medium dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                  />
                </div>

                <div className="flex gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => setMode('login')}
                    className="w-1/2 rounded-xl border border-slate-200 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-50 dark:border-slate-700 dark:text-slate-300"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="w-1/2 rounded-xl bg-indigo-600 py-2 text-xs font-bold text-white hover:bg-indigo-700"
                  >
                    Send Reset Link
                  </button>
                </div>
              </form>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
