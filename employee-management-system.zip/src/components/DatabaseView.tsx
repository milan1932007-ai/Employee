import React, { useState } from 'react';
import {
  Database,
  CheckCircle2,
  AlertCircle,
  Copy,
  ExternalLink,
  ShieldAlert,
  Server,
  Terminal,
  Code2,
  RefreshCw,
  Layers,
} from 'lucide-react';

interface DatabaseViewProps {
  isSupabaseLive?: boolean;
  counts: {
    employees: number;
    departments: number;
    attendance: number;
    salaries: number;
    leaves: number;
    performance: number;
  };
  onRefresh: () => void;
}

export const DatabaseView: React.FC<DatabaseViewProps> = ({
  isSupabaseLive,
  counts,
  onRefresh,
}) => {
  const [copied, setCopied] = useState(false);

  const envSample = `# .env configuration for Supabase
SUPABASE_URL=https://your-project.supabase.co
SUPABASE_SERVICE_ROLE_KEY=eyJh...your-service-role-key...`;

  const handleCopyEnv = () => {
    navigator.clipboard.writeText(envSample);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h2 className="text-xl font-bold tracking-tight text-slate-900 dark:text-white">
            Database Architecture & Supabase Integration
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Relational PostgreSQL schema, Row-Level Security (RLS) enforcement, and dual-mode data persistence.
          </p>
        </div>

        <button
          onClick={onRefresh}
          className="inline-flex items-center gap-1.5 rounded-xl border border-slate-200 bg-white px-3.5 py-2 text-xs font-semibold text-slate-700 shadow-sm hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 transition-colors"
        >
          <RefreshCw className="h-3.5 w-3.5" />
          <span>Sync Tables</span>
        </button>
      </div>

      {/* Persistence Mode Banner */}
      <div
        className={`rounded-2xl border p-5 ${
          isSupabaseLive
            ? 'border-emerald-200 bg-emerald-50/50 dark:border-emerald-900/50 dark:bg-emerald-950/20'
            : 'border-indigo-200 bg-indigo-50/50 dark:border-indigo-900/50 dark:bg-indigo-950/20'
        }`}
      >
        <div className="flex items-start gap-4">
          <div
            className={`rounded-xl p-3 ${
              isSupabaseLive
                ? 'bg-emerald-600 text-white'
                : 'bg-indigo-600 text-white'
            }`}
          >
            <Database className="h-6 w-6" />
          </div>
          <div className="flex-1">
            <div className="flex items-center gap-2">
              <h3 className="font-bold text-slate-900 dark:text-white text-sm">
                Active Persistence Engine: {isSupabaseLive ? 'Supabase PostgreSQL (Live)' : 'High-Performance In-Memory Data Store with Supabase Schema'}
              </h3>
              <span
                className={`inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[10px] font-bold ${
                  isSupabaseLive
                    ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-900 dark:text-emerald-200'
                    : 'bg-indigo-100 text-indigo-800 dark:bg-indigo-900 dark:text-indigo-200'
                }`}
              >
                <CheckCircle2 className="h-3 w-3" />
                {isSupabaseLive ? 'Connected' : 'Autonomous Fallback'}
              </span>
            </div>
            <p className="mt-1 text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
              {isSupabaseLive
                ? 'The application is actively reading and writing to your remote Supabase PostgreSQL cluster with full ACID guarantees and real-time triggers.'
                : 'The system is running on a zero-config data layer mimicking the full Supabase schema. When SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY are added to the environment, it automatically connects to live cloud PostgreSQL!'}
            </p>
          </div>
        </div>
      </div>

      {/* Relational Table Stats Grid */}
      <div>
        <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-3">
          Relational Database Entities
        </h3>
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-6">
          <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm dark:border-slate-800 dark:bg-slate-900">
            <span className="text-[11px] font-bold text-slate-400">public.employees</span>
            <div className="text-2xl font-black text-slate-900 dark:text-white mt-1">
              {counts.employees}
            </div>
            <span className="text-[10px] text-slate-500">Rows active</span>
          </div>

          <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm dark:border-slate-800 dark:bg-slate-900">
            <span className="text-[11px] font-bold text-slate-400">public.departments</span>
            <div className="text-2xl font-black text-slate-900 dark:text-white mt-1">
              {counts.departments}
            </div>
            <span className="text-[10px] text-slate-500">Divisions</span>
          </div>

          <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm dark:border-slate-800 dark:bg-slate-900">
            <span className="text-[11px] font-bold text-slate-400">public.attendance</span>
            <div className="text-2xl font-black text-slate-900 dark:text-white mt-1">
              {counts.attendance}
            </div>
            <span className="text-[10px] text-slate-500">Punches logged</span>
          </div>

          <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm dark:border-slate-800 dark:bg-slate-900">
            <span className="text-[11px] font-bold text-slate-400">public.salaries</span>
            <div className="text-2xl font-black text-slate-900 dark:text-white mt-1">
              {counts.salaries}
            </div>
            <span className="text-[10px] text-slate-500">Disbursements</span>
          </div>

          <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm dark:border-slate-800 dark:bg-slate-900">
            <span className="text-[11px] font-bold text-slate-400">public.leaves</span>
            <div className="text-2xl font-black text-slate-900 dark:text-white mt-1">
              {counts.leaves}
            </div>
            <span className="text-[10px] text-slate-500">Applications</span>
          </div>

          <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm dark:border-slate-800 dark:bg-slate-900">
            <span className="text-[11px] font-bold text-slate-400">public.performance</span>
            <div className="text-2xl font-black text-slate-900 dark:text-white mt-1">
              {counts.performance}
            </div>
            <span className="text-[10px] text-slate-500">Appraisals</span>
          </div>
        </div>
      </div>

      {/* Supabase Schema & Setup Guide */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        {/* Environment Configuration Guide */}
        <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm dark:border-slate-800 dark:bg-slate-900 space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Server className="h-4 w-4 text-indigo-600" />
              <h4 className="font-bold text-slate-900 dark:text-white text-xs uppercase tracking-wider">
                Supabase Cloud Connection
              </h4>
            </div>
            <button
              onClick={handleCopyEnv}
              className="inline-flex items-center gap-1 rounded-lg bg-slate-100 px-2.5 py-1 text-xs font-semibold text-slate-700 hover:bg-slate-200 dark:bg-slate-800 dark:text-slate-300"
            >
              <Copy className="h-3 w-3" />
              <span>{copied ? 'Copied!' : 'Copy Config'}</span>
            </button>
          </div>

          <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
            To connect to your own Supabase project, execute the SQL script in your Supabase SQL Editor and define the following variables in Settings &gt; Secrets:
          </p>

          <div className="rounded-xl bg-slate-900 p-3 font-mono text-[11px] text-slate-200">
            <pre className="overflow-x-auto">{envSample}</pre>
          </div>

          <div className="rounded-xl bg-amber-50 p-3 text-xs text-amber-800 dark:bg-amber-950/40 dark:text-amber-300 border border-amber-200 dark:border-amber-900/50">
            <div className="flex items-center gap-1.5 font-bold">
              <ShieldAlert className="h-4 w-4 shrink-0" />
              <span>Security Note: Service Role Key</span>
            </div>
            <p className="mt-1 text-[11px] leading-relaxed">
              The backend Express server uses the Supabase service role key strictly on the server side to bypass client-side CORS and safely perform verified role-based operations.
            </p>
          </div>
        </div>

        {/* Database Schema Details */}
        <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm dark:border-slate-800 dark:bg-slate-900 space-y-3">
          <div className="flex items-center gap-2">
            <Code2 className="h-4 w-4 text-emerald-600" />
            <h4 className="font-bold text-slate-900 dark:text-white text-xs uppercase tracking-wider">
              PostgreSQL Schema (supabase-schema.sql)
            </h4>
          </div>

          <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
            The database schema file <code className="rounded bg-slate-100 px-1 py-0.5 font-mono text-[11px] text-indigo-600 dark:bg-slate-800 dark:text-indigo-400">supabase-schema.sql</code> contains:
          </p>

          <ul className="space-y-2 text-xs text-slate-600 dark:text-slate-300">
            <li className="flex items-center gap-2">
              <CheckCircle2 className="h-4 w-4 text-emerald-500 shrink-0" />
              <span>Complete DDL tables for employees, departments, attendance, salaries, leaves, and reviews.</span>
            </li>
            <li className="flex items-center gap-2">
              <CheckCircle2 className="h-4 w-4 text-emerald-500 shrink-0" />
              <span>Foreign key constraints linking employees to departments and payroll records.</span>
            </li>
            <li className="flex items-center gap-2">
              <CheckCircle2 className="h-4 w-4 text-emerald-500 shrink-0" />
              <span>Row Level Security (RLS) policies enforcing role isolation (Admin, HR Manager, Employee).</span>
            </li>
            <li className="flex items-center gap-2">
              <CheckCircle2 className="h-4 w-4 text-emerald-500 shrink-0" />
              <span>Production seed datasets with multi-department enterprise staff.</span>
            </li>
          </ul>
        </div>
      </div>
    </div>
  );
};
