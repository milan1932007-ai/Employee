import React, { useState } from 'react';
import {
  Wallet,
  DollarSign,
  FileText,
  Printer,
  Plus,
  FileSpreadsheet,
  Download,
  X,
  Building,
  CheckCircle2,
} from 'lucide-react';
import type { SalaryRecord, Employee, UserRole } from '../types.ts';
import { exportToExcel, exportToPDF } from '../utils/exportUtils.ts';

interface SalaryViewProps {
  salaries: SalaryRecord[];
  employees: Employee[];
  userRole: UserRole;
  onCreateSalary: (data: Partial<SalaryRecord>) => Promise<void>;
}

export const SalaryView: React.FC<SalaryViewProps> = ({
  salaries,
  employees,
  userRole,
  onCreateSalary,
}) => {
  const [showProcessModal, setShowProcessModal] = useState(false);
  const [showPayslipModal, setShowPayslipModal] = useState(false);
  const [selectedRecord, setSelectedRecord] = useState<SalaryRecord | null>(null);

  // Form State
  const [formEmployeeId, setFormEmployeeId] = useState(employees[0]?.employee_id || '');
  const [formBasicSalary, setFormBasicSalary] = useState<number>(7500);
  const [formAllowances, setFormAllowances] = useState<number>(1200);
  const [formDeductions, setFormDeductions] = useState<number>(850);
  const [formMonthYear, setFormMonthYear] = useState('Aug 2026');
  const [formPaymentDate, setFormPaymentDate] = useState(new Date().toISOString().split('T')[0]);
  const [formStatus, setFormStatus] = useState<'Paid' | 'Pending'>('Paid');
  const [saving, setSaving] = useState(false);

  // Month filter
  const [selectedMonth, setSelectedMonth] = useState('all');

  const months = Array.from(new Set(salaries.map((s) => s.month_year)));

  const filteredSalaries = salaries.filter((s) => {
    return selectedMonth === 'all' || s.month_year === selectedMonth;
  });

  const totalPayroll = filteredSalaries.reduce((sum, s) => sum + Number(s.net_salary), 0);
  const totalAllowances = filteredSalaries.reduce((sum, s) => sum + Number(s.allowances), 0);
  const totalDeductions = filteredSalaries.reduce((sum, s) => sum + Number(s.deductions), 0);

  const handleEmployeeSelect = (empId: string) => {
    setFormEmployeeId(empId);
    const emp = employees.find((e) => e.employee_id === empId);
    if (emp) {
      const monthly = Math.round(Number(emp.salary) / 12);
      setFormBasicSalary(monthly);
      setFormAllowances(Math.round(monthly * 0.15));
      setFormDeductions(Math.round(monthly * 0.1));
    }
  };

  const handleOpenProcess = () => {
    if (employees[0]) {
      handleEmployeeSelect(employees[0].employee_id);
    }
    setShowProcessModal(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      await onCreateSalary({
        employee_id: formEmployeeId,
        basic_salary: Number(formBasicSalary),
        allowances: Number(formAllowances),
        deductions: Number(formDeductions),
        month_year: formMonthYear,
        payment_date: formPaymentDate,
        payment_status: formStatus,
      });
      setShowProcessModal(false);
    } catch (err: any) {
      alert(err.message || 'Failed to process salary.');
    } finally {
      setSaving(false);
    }
  };

  const handleOpenPayslip = (record: SalaryRecord) => {
    setSelectedRecord(record);
    setShowPayslipModal(true);
  };

  const handleExportExcel = () => {
    const data = filteredSalaries.map((s) => ({
      'Payment Date': s.payment_date,
      Month: s.month_year,
      'Employee ID': s.employee_id,
      'Employee Name': s.employee_name || employees.find((e) => e.employee_id === s.employee_id)?.full_name || s.employee_id,
      'Basic Salary ($)': s.basic_salary,
      'Allowances ($)': s.allowances,
      'Deductions ($)': s.deductions,
      'Net Salary ($)': s.net_salary,
      Status: s.payment_status,
    }));
    exportToExcel(data, `Payroll_Summary_${selectedMonth}`);
  };

  const handleExportPDF = () => {
    const columns = [
      { header: 'Month', dataKey: 'month_year' },
      { header: 'Employee', dataKey: 'employee_name' },
      { header: 'Basic ($)', dataKey: 'basic_salary' },
      { header: 'Allowances ($)', dataKey: 'allowances' },
      { header: 'Deductions ($)', dataKey: 'deductions' },
      { header: 'Net Salary ($)', dataKey: 'net_salary' },
      { header: 'Status', dataKey: 'payment_status' },
    ];
    exportToPDF(`Payroll Disbursal Report (${selectedMonth})`, columns, filteredSalaries, `Payroll_${selectedMonth}`);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h2 className="text-xl font-bold tracking-tight text-slate-900 dark:text-white">
            Salary & Payroll Management
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Calculate allowances and deductions, disburse monthly wages, and generate printable employee payslips.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={handleExportExcel}
            className="inline-flex items-center gap-1.5 rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs font-semibold text-slate-700 shadow-sm hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-300"
          >
            <FileSpreadsheet className="h-3.5 w-3.5 text-emerald-600" />
            <span>Excel</span>
          </button>
          <button
            onClick={handleExportPDF}
            className="inline-flex items-center gap-1.5 rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs font-semibold text-slate-700 shadow-sm hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-300"
          >
            <Download className="h-3.5 w-3.5 text-rose-600" />
            <span>PDF</span>
          </button>

          {userRole !== 'Employee' && (
            <button
              onClick={handleOpenProcess}
              className="inline-flex items-center gap-1.5 rounded-xl bg-indigo-600 px-3.5 py-2 text-xs font-semibold text-white shadow-sm hover:bg-indigo-700 transition-colors"
            >
              <Plus className="h-3.5 w-3.5" />
              <span>Process Salary</span>
            </button>
          )}
        </div>
      </div>

      {/* Summary KPI Cards */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
        <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm dark:border-slate-800 dark:bg-slate-900">
          <div className="text-xs font-bold uppercase tracking-wider text-slate-400">
            Total Net Payroll Disbursed
          </div>
          <div className="mt-2 text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white">
            ${totalPayroll.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </div>
          <p className="mt-1 text-[11px] text-slate-500">
            For {filteredSalaries.length} employee disbursement records
          </p>
        </div>

        <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm dark:border-slate-800 dark:bg-slate-900">
          <div className="text-xs font-bold uppercase tracking-wider text-emerald-600">
            Total Allowances & Bonuses
          </div>
          <div className="mt-2 text-2xl sm:text-3xl font-extrabold text-emerald-600">
            +${totalAllowances.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </div>
          <p className="mt-1 text-[11px] text-slate-500">
            Medical, housing, travel & performance incentives
          </p>
        </div>

        <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm dark:border-slate-800 dark:bg-slate-900">
          <div className="text-xs font-bold uppercase tracking-wider text-rose-600">
            Total Tax & Statutory Deductions
          </div>
          <div className="mt-2 text-2xl sm:text-3xl font-extrabold text-rose-600">
            -${totalDeductions.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </div>
          <p className="mt-1 text-[11px] text-slate-500">
            Withholding tax, pension & healthcare contributions
          </p>
        </div>
      </div>

      {/* Month Filter */}
      <div className="flex items-center justify-between rounded-2xl border border-slate-200 bg-white p-3 shadow-sm dark:border-slate-800 dark:bg-slate-900">
        <div className="flex items-center gap-2">
          <span className="text-xs font-semibold text-slate-500">Payroll Cycle:</span>
          <select
            value={selectedMonth}
            onChange={(e) => setSelectedMonth(e.target.value)}
            className="rounded-xl border border-slate-200 bg-slate-50 px-3 py-1.5 text-xs font-medium text-slate-800 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
          >
            <option value="all">All Pay Periods</option>
            {months.map((m) => (
              <option key={m} value={m}>
                {m}
              </option>
            ))}
          </select>
        </div>

        <div className="text-xs font-semibold text-indigo-600 dark:text-indigo-400">
          Showing {filteredSalaries.length} payslips
        </div>
      </div>

      {/* Salary Records Table */}
      <div className="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm dark:border-slate-800 dark:bg-slate-900">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="border-b border-slate-200 bg-slate-50/75 font-bold uppercase tracking-wider text-slate-500 dark:border-slate-800 dark:bg-slate-800/50 dark:text-slate-400">
              <tr>
                <th className="px-4 py-3.5">Employee</th>
                <th className="px-4 py-3.5">Cycle</th>
                <th className="px-4 py-3.5">Basic Salary</th>
                <th className="px-4 py-3.5">Allowances (+)</th>
                <th className="px-4 py-3.5">Deductions (-)</th>
                <th className="px-4 py-3.5">Net Salary</th>
                <th className="px-4 py-3.5">Payment Date</th>
                <th className="px-4 py-3.5">Status</th>
                <th className="px-4 py-3.5 text-right">Payslip</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {filteredSalaries.map((sal) => {
                const emp = employees.find((e) => e.employee_id === sal.employee_id);
                return (
                  <tr
                    key={sal.id}
                    className="hover:bg-slate-50/80 dark:hover:bg-slate-800/50 transition-colors"
                  >
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-3">
                        <img
                          src={emp?.photo_url || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&h=100&fit=crop&crop=faces'}
                          alt={emp?.full_name || sal.employee_id}
                          className="h-8 w-8 rounded-full object-cover border border-slate-200 dark:border-slate-700"
                        />
                        <div>
                          <div className="font-bold text-slate-900 dark:text-white">
                            {emp?.full_name || sal.employee_name || sal.employee_id}
                          </div>
                          <div className="text-[10px] text-slate-400 font-mono">
                            {sal.employee_id}
                          </div>
                        </div>
                      </div>
                    </td>
                    <td className="px-4 py-3 font-semibold text-slate-700 dark:text-slate-300">
                      {sal.month_year}
                    </td>
                    <td className="px-4 py-3 font-mono text-slate-700 dark:text-slate-300">
                      ${Number(sal.basic_salary).toLocaleString(undefined, { minimumFractionDigits: 2 })}
                    </td>
                    <td className="px-4 py-3 font-mono font-medium text-emerald-600">
                      +${Number(sal.allowances).toLocaleString(undefined, { minimumFractionDigits: 2 })}
                    </td>
                    <td className="px-4 py-3 font-mono font-medium text-rose-600">
                      -${Number(sal.deductions).toLocaleString(undefined, { minimumFractionDigits: 2 })}
                    </td>
                    <td className="px-4 py-3 font-mono font-bold text-slate-900 dark:text-white">
                      ${Number(sal.net_salary).toLocaleString(undefined, { minimumFractionDigits: 2 })}
                    </td>
                    <td className="px-4 py-3 text-slate-500 dark:text-slate-400">
                      {sal.payment_date}
                    </td>
                    <td className="px-4 py-3">
                      <span className="inline-flex items-center gap-1 rounded-full bg-emerald-50 px-2 py-0.5 text-[10px] font-bold text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-300">
                        <CheckCircle2 className="h-3 w-3" />
                        {sal.payment_status}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-right">
                      <button
                        onClick={() => handleOpenPayslip(sal)}
                        className="inline-flex items-center gap-1 rounded-lg bg-indigo-50 px-2.5 py-1 text-xs font-semibold text-indigo-600 hover:bg-indigo-100 dark:bg-indigo-950/60 dark:text-indigo-400 transition-colors"
                      >
                        <FileText className="h-3.5 w-3.5" />
                        <span>View Payslip</span>
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal 1: Process Salary */}
      {showProcessModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
          <div className="relative w-full max-w-md rounded-2xl bg-white p-6 shadow-2xl dark:bg-slate-900 dark:border dark:border-slate-800">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3 dark:border-slate-800">
              <h3 className="text-base font-bold text-slate-900 dark:text-white">
                Process Monthly Salary
              </h3>
              <button
                onClick={() => setShowProcessModal(false)}
                className="rounded-lg p-1 text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="mt-4 space-y-3.5">
              <div>
                <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                  Select Employee *
                </label>
                <select
                  value={formEmployeeId}
                  onChange={(e) => handleEmployeeSelect(e.target.value)}
                  className="mt-1 w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs font-medium dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                >
                  {employees.map((e) => (
                    <option key={e.id} value={e.employee_id}>
                      {e.employee_id} — {e.full_name} (${Number(e.salary).toLocaleString()}/yr)
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                    Pay Month / Year *
                  </label>
                  <input
                    type="text"
                    required
                    value={formMonthYear}
                    onChange={(e) => setFormMonthYear(e.target.value)}
                    placeholder="Sep 2026"
                    className="mt-1 w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs font-medium dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                    Disbursal Date *
                  </label>
                  <input
                    type="date"
                    required
                    value={formPaymentDate}
                    onChange={(e) => setFormPaymentDate(e.target.value)}
                    className="mt-1 w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs font-medium dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                  Basic Monthly Salary ($) *
                </label>
                <input
                  type="number"
                  required
                  min="0"
                  step="10"
                  value={formBasicSalary}
                  onChange={(e) => setFormBasicSalary(Number(e.target.value))}
                  className="mt-1 w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs font-mono font-bold dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-bold uppercase tracking-wider text-emerald-600">
                    Allowances ($)
                  </label>
                  <input
                    type="number"
                    min="0"
                    step="10"
                    value={formAllowances}
                    onChange={(e) => setFormAllowances(Number(e.target.value))}
                    className="mt-1 w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs font-mono dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-bold uppercase tracking-wider text-rose-600">
                    Deductions ($)
                  </label>
                  <input
                    type="number"
                    min="0"
                    step="10"
                    value={formDeductions}
                    onChange={(e) => setFormDeductions(Number(e.target.value))}
                    className="mt-1 w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs font-mono dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                  />
                </div>
              </div>

              {/* Calculated Net Preview */}
              <div className="rounded-xl bg-indigo-50 p-3 text-xs dark:bg-indigo-950/40 border border-indigo-100 dark:border-indigo-900">
                <div className="flex items-center justify-between font-bold text-slate-700 dark:text-slate-200">
                  <span>Calculated Net Salary:</span>
                  <span className="text-base text-indigo-600 dark:text-indigo-400 font-mono">
                    ${(formBasicSalary + formAllowances - formDeductions).toFixed(2)}
                  </span>
                </div>
                <p className="mt-1 text-[10px] text-slate-500 dark:text-slate-400">
                  Formula: Basic (${formBasicSalary}) + Allowances (${formAllowances}) - Deductions (${formDeductions})
                </p>
              </div>

              <div className="mt-6 flex justify-end gap-2 border-t border-slate-100 pt-4 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowProcessModal(false)}
                  className="rounded-xl border border-slate-200 px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-50 dark:border-slate-700 dark:text-slate-300"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={saving}
                  className="rounded-xl bg-indigo-600 px-4 py-2 text-xs font-semibold text-white shadow-sm hover:bg-indigo-700 disabled:opacity-50"
                >
                  {saving ? 'Processing...' : 'Disburse Payroll'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal 2: Interactive Printable Payslip */}
      {showPayslipModal && selectedRecord && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm overflow-y-auto">
          <div className="relative w-full max-w-2xl rounded-2xl bg-white p-8 shadow-2xl dark:bg-slate-900 dark:border dark:border-slate-800 my-8">
            <div className="flex items-center justify-between border-b border-slate-200 pb-4 dark:border-slate-800">
              <div className="flex items-center gap-2">
                <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-indigo-600 text-white font-bold">
                  EM
                </div>
                <div>
                  <h3 className="text-base font-bold text-slate-900 dark:text-white">
                    Official Salary Slip
                  </h3>
                  <p className="text-[11px] text-slate-500">EmployeeHub Global Inc.</p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => window.print()}
                  className="inline-flex items-center gap-1 rounded-lg border border-slate-200 px-3 py-1.5 text-xs font-semibold text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:text-slate-200"
                >
                  <Printer className="h-3.5 w-3.5 text-slate-500" />
                  <span>Print Slip</span>
                </button>
                <button
                  onClick={() => setShowPayslipModal(false)}
                  className="rounded-lg p-1 text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800"
                >
                  <X className="h-5 w-5" />
                </button>
              </div>
            </div>

            {/* Payslip Body */}
            <div className="mt-6 space-y-6 text-xs">
              {/* Employee Metadata */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 rounded-xl bg-slate-50 p-4 dark:bg-slate-800/60">
                <div>
                  <div className="text-[10px] uppercase font-bold text-slate-400">Employee Name</div>
                  <div className="font-bold text-slate-900 dark:text-white mt-0.5">
                    {selectedRecord.employee_name}
                  </div>
                </div>
                <div>
                  <div className="text-[10px] uppercase font-bold text-slate-400">Employee ID</div>
                  <div className="font-mono font-bold text-indigo-600 dark:text-indigo-400 mt-0.5">
                    {selectedRecord.employee_id}
                  </div>
                </div>
                <div>
                  <div className="text-[10px] uppercase font-bold text-slate-400">Pay Period</div>
                  <div className="font-bold text-slate-900 dark:text-white mt-0.5">
                    {selectedRecord.month_year}
                  </div>
                </div>
                <div>
                  <div className="text-[10px] uppercase font-bold text-slate-400">Disbursal Date</div>
                  <div className="font-bold text-slate-900 dark:text-white mt-0.5">
                    {selectedRecord.payment_date}
                  </div>
                </div>
              </div>

              {/* Earnings & Deductions Tables */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {/* Earnings */}
                <div className="rounded-xl border border-slate-200 p-4 dark:border-slate-700">
                  <h4 className="font-bold text-slate-900 dark:text-white text-xs uppercase border-b border-slate-100 pb-2 dark:border-slate-800">
                    Earnings
                  </h4>
                  <div className="mt-3 space-y-2">
                    <div className="flex justify-between">
                      <span className="text-slate-500">Basic Salary</span>
                      <span className="font-mono font-semibold text-slate-900 dark:text-white">
                        ${Number(selectedRecord.basic_salary).toFixed(2)}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-500">Allowances & Benefits</span>
                      <span className="font-mono font-semibold text-emerald-600">
                        +${Number(selectedRecord.allowances).toFixed(2)}
                      </span>
                    </div>
                    <div className="border-t border-slate-100 pt-2 flex justify-between font-bold dark:border-slate-800">
                      <span>Total Gross Earnings</span>
                      <span className="font-mono text-indigo-600 dark:text-indigo-400">
                        ${(Number(selectedRecord.basic_salary) + Number(selectedRecord.allowances)).toFixed(2)}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Deductions */}
                <div className="rounded-xl border border-slate-200 p-4 dark:border-slate-700">
                  <h4 className="font-bold text-slate-900 dark:text-white text-xs uppercase border-b border-slate-100 pb-2 dark:border-slate-800">
                    Deductions
                  </h4>
                  <div className="mt-3 space-y-2">
                    <div className="flex justify-between">
                      <span className="text-slate-500">Income Tax & Social Security</span>
                      <span className="font-mono font-semibold text-rose-600">
                        -${(Number(selectedRecord.deductions) * 0.75).toFixed(2)}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-500">Health Insurance & Misc</span>
                      <span className="font-mono font-semibold text-rose-600">
                        -${(Number(selectedRecord.deductions) * 0.25).toFixed(2)}
                      </span>
                    </div>
                    <div className="border-t border-slate-100 pt-2 flex justify-between font-bold dark:border-slate-800">
                      <span>Total Deductions</span>
                      <span className="font-mono text-rose-600">
                        -${Number(selectedRecord.deductions).toFixed(2)}
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Net Pay Highlight Banner */}
              <div className="rounded-xl bg-gradient-to-r from-indigo-900 to-slate-900 p-5 text-white flex items-center justify-between">
                <div>
                  <div className="text-[10px] font-bold uppercase tracking-wider text-indigo-200">
                    Net Take-Home Salary
                  </div>
                  <div className="text-2xl font-black font-mono mt-0.5">
                    ${Number(selectedRecord.net_salary).toFixed(2)}
                  </div>
                </div>
                <div className="text-right text-[11px] text-indigo-200">
                  <div>Status: Verified & Disbursed</div>
                  <div>Direct Deposit to Bank on File</div>
                </div>
              </div>
            </div>

            <div className="mt-6 flex justify-end">
              <button
                onClick={() => setShowPayslipModal(false)}
                className="rounded-xl bg-slate-100 px-4 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-200 dark:bg-slate-800 dark:text-slate-300"
              >
                Close Payslip
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
