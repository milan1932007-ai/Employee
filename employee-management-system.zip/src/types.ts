export type UserRole = 'Admin' | 'HR Manager' | 'Employee';

export interface User {
  id: string;
  email: string;
  full_name: string;
  role: UserRole;
  employee_id?: string;
  avatar?: string;
  status?: string;
  created_at?: string;
}

export type UserSession = User;

export interface Department {
  id: string;
  department_name: string;
  department_head: string;
  description: string;
  created_at?: string;
  employee_count?: number;
}

export interface Employee {
  id: string;
  employee_id: string;
  full_name: string;
  gender: 'Male' | 'Female' | 'Other';
  dob: string;
  email: string;
  phone: string;
  address: string;
  department_id: string;
  department_name?: string;
  designation: string;
  joining_date: string;
  salary: number;
  photo_url: string;
  status?: 'Active' | 'On Leave' | 'Terminated';
  created_at?: string;
}

export interface Attendance {
  id: string;
  employee_id: string;
  employee_name?: string;
  department_name?: string;
  date: string;
  status: 'Present' | 'Absent' | 'Half Day' | 'On Leave';
  check_in?: string;
  check_out?: string;
  created_at?: string;
}

export interface Leave {
  id: string;
  employee_id: string;
  employee_name?: string;
  department_name?: string;
  leave_type: 'Casual' | 'Sick' | 'Paid' | 'Maternity/Paternity' | 'Unpaid';
  start_date: string;
  end_date: string;
  days_count: number;
  reason: string;
  status: 'Pending' | 'Approved' | 'Rejected';
  applied_at: string;
  approved_by?: string;
}

export interface SalaryRecord {
  id: string;
  employee_id: string;
  employee_name?: string;
  designation?: string;
  department_name?: string;
  basic_salary: number;
  allowances: number;
  deductions: number;
  net_salary: number;
  payment_date: string;
  payment_status: 'Paid' | 'Pending';
  month_year: string;
  created_at?: string;
}

export interface Performance {
  id: string;
  employee_id: string;
  employee_name?: string;
  designation?: string;
  department_name?: string;
  rating: number; // 1 to 5
  achievements: string;
  feedback: string;
  review_date: string;
  reviewer_name?: string;
  created_at?: string;
}

export interface Activity {
  id: string;
  type: 'employee' | 'leave' | 'salary' | 'attendance' | 'performance';
  action: string;
  timestamp: string;
  user: string;
}

export interface DashboardStats {
  totalEmployees: number;
  totalDepartments: number;
  presentToday: number;
  absentToday: number;
  onLeaveToday: number;
  monthlySalaryExpenses: number;
  recentActivities: Activity[];
  departmentDistribution: { name: string; count: number }[];
  attendanceTrend: { date: string; present: number; absent: number }[];
}

export interface DatabaseStatus {
  isSupabaseConfigured: boolean;
  supabaseUrl?: string;
  connectionHealthy: boolean;
  driver: 'supabase' | 'local_persistence';
  totalRecords: {
    employees: number;
    departments: number;
    attendance: number;
    leaves: number;
    salaries: number;
    performance: number;
  };
}
