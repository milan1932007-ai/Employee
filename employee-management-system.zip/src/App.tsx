import React, { useState, useEffect, useCallback } from 'react';
import { Navbar } from './components/Navbar.tsx';
import { Sidebar, ActiveTab } from './components/Sidebar.tsx';
import { DashboardView } from './components/DashboardView.tsx';
import { EmployeesView } from './components/EmployeesView.tsx';
import { DepartmentsView } from './components/DepartmentsView.tsx';
import { AttendanceView } from './components/AttendanceView.tsx';
import { SalaryView } from './components/SalaryView.tsx';
import { LeavesView } from './components/LeavesView.tsx';
import { PerformanceView } from './components/PerformanceView.tsx';
import { ReportsView } from './components/ReportsView.tsx';
import { DatabaseView } from './components/DatabaseView.tsx';
import { AuthModal } from './components/AuthModal.tsx';
import { api } from './api.ts';
import type {
  Employee,
  Department,
  Attendance,
  Leave,
  SalaryRecord,
  Performance,
  DashboardStats,
  User,
  UserRole,
  UserSession,
} from './types.ts';

const DEFAULT_USER: User = {
  id: 'usr_admin',
  email: 'admin@enterprise.org',
  role: 'Admin',
  employee_id: 'EMP001',
  full_name: 'Alexander Wright',
  status: 'active',
  created_at: new Date().toISOString(),
};

export default function App() {
  const [currentUser, setCurrentUser] = useState<User>(() => {
    const saved = localStorage.getItem('ems_user');
    return saved ? JSON.parse(saved) : DEFAULT_USER;
  });

  const [activeTab, setActiveTab] = useState<ActiveTab>('dashboard');
  const [mobileSidebarOpen, setMobileSidebarOpen] = useState(false);
  const [authModalOpen, setAuthModalOpen] = useState(false);

  // Dark Mode
  const [darkMode, setDarkMode] = useState<boolean>(() => {
    return localStorage.getItem('ems_dark_mode') === 'true';
  });

  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
      localStorage.setItem('ems_dark_mode', 'true');
    } else {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('ems_dark_mode', 'false');
    }
  }, [darkMode]);

  // Data Store
  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [departments, setDepartments] = useState<Department[]>([]);
  const [attendance, setAttendance] = useState<Attendance[]>([]);
  const [leaves, setLeaves] = useState<Leave[]>([]);
  const [salaries, setSalaries] = useState<SalaryRecord[]>([]);
  const [performance, setPerformance] = useState<Performance[]>([]);
  const [isSupabaseLive, setIsSupabaseLive] = useState(false);

  // Notification Banner
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3500);
  };

  const loadAllData = useCallback(async () => {
    try {
      setLoading(true);
      const [
        statsData,
        empData,
        deptData,
        attData,
        leaveData,
        salData,
        perfData,
        dbStatus,
      ] = await Promise.all([
        api.getStats().catch(() => null),
        api.getEmployees().catch(() => []),
        api.getDepartments().catch(() => []),
        api.getAttendance().catch(() => []),
        api.getLeaves().catch(() => []),
        api.getSalaries().catch(() => []),
        api.getPerformance().catch(() => []),
        api.getDbStatus().catch(() => ({ isSupabaseConfigured: false } as any)),
      ]);

      if (statsData) setStats(statsData);
      if (empData) setEmployees(empData);
      if (deptData) setDepartments(deptData);
      if (attData) setAttendance(attData);
      if (leaveData) setLeaves(leaveData);
      if (salData) setSalaries(salData);
      if (perfData) setPerformance(perfData);
      if (dbStatus) setIsSupabaseLive(!!dbStatus.isSupabaseConfigured);
    } catch (err) {
      console.error('Failed to load application data:', err);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadAllData();
  }, [loadAllData]);

  // Role Switcher
  const handleRoleSwitch = (newRole: UserRole) => {
    const updated = {
      ...currentUser,
      role: newRole,
      full_name:
        newRole === 'Admin'
          ? 'Alexander Wright'
          : newRole === 'HR Manager'
          ? 'Sarah Jenkins'
          : 'Michael Chen',
    };
    setCurrentUser(updated);
    localStorage.setItem('ems_user', JSON.stringify(updated));
    showToast(`Role switched to ${newRole}`);

    // If on a forbidden tab, bounce to dashboard
    if (
      newRole === 'Employee' &&
      ['employees', 'departments', 'reports', 'database'].includes(activeTab)
    ) {
      setActiveTab('dashboard');
    }
  };

  // Auth Handlers
  const handleLogout = () => {
    setAuthModalOpen(true);
  };

  const handleLoginSuccess = (userSession: UserSession) => {
    const user: User = {
      id: userSession.id,
      email: userSession.email,
      role: userSession.role,
      employee_id: userSession.employee_id,
      full_name: userSession.full_name,
      status: 'active',
      created_at: new Date().toISOString(),
    };
    setCurrentUser(user);
    localStorage.setItem('ems_user', JSON.stringify(user));
    showToast(`Welcome back, ${user.full_name} (${user.role})`);
  };

  // Employee CRUD Handlers
  const handleSaveEmployee = async (employeeData: Partial<Employee>, isEdit: boolean) => {
    if (isEdit && employeeData.id) {
      const updated = await api.updateEmployee(employeeData.id, employeeData);
      setEmployees((prev) => prev.map((e) => (e.id === updated.id ? updated : e)));
      showToast(`Updated employee ${updated.full_name}`);
    } else {
      const created = await api.createEmployee(employeeData);
      setEmployees((prev) => [created, ...prev]);
      showToast(`Added employee ${created.full_name}`);
    }
    api.getStats().then((s) => setStats(s)).catch(() => {});
  };

  const handleDeleteEmployee = async (id: string) => {
    await api.deleteEmployee(id);
    setEmployees((prev) => prev.filter((e) => e.id !== id));
    showToast('Employee deleted successfully');
    api.getStats().then((s) => setStats(s)).catch(() => {});
  };

  // Department CRUD Handlers
  const handleSaveDepartment = async (deptData: Partial<Department>, isEdit: boolean) => {
    if (isEdit && deptData.id) {
      const updated = await api.updateDepartment(deptData.id, deptData);
      setDepartments((prev) => prev.map((d) => (d.id === updated.id ? updated : d)));
      showToast(`Updated department ${updated.department_name}`);
    } else {
      const created = await api.createDepartment(deptData);
      setDepartments((prev) => [created, ...prev]);
      showToast(`Created department ${created.department_name}`);
    }
    api.getStats().then((s) => setStats(s)).catch(() => {});
  };

  const handleDeleteDepartment = async (id: string) => {
    await api.deleteDepartment(id);
    setDepartments((prev) => prev.filter((d) => d.id !== id));
    showToast('Department removed');
    api.getStats().then((s) => setStats(s)).catch(() => {});
  };

  // Attendance Handler
  const handleMarkAttendance = async (data: {
    employee_id: string;
    date: string;
    status: Attendance['status'];
    check_in?: string;
    check_out?: string;
  }) => {
    const updated = await api.markAttendance(data);
    setAttendance((prev) => {
      const exists = prev.some((a) => a.id === updated.id || (a.employee_id === data.employee_id && a.date === data.date));
      if (exists) {
        return prev.map((a) =>
          a.id === updated.id || (a.employee_id === data.employee_id && a.date === data.date) ? updated : a
        );
      }
      return [updated, ...prev];
    });
    showToast(`Attendance marked for ${data.employee_id}: ${data.status}`);
    api.getStats().then((s) => setStats(s)).catch(() => {});
  };

  // Salary Handler
  const handleCreateSalary = async (data: Partial<SalaryRecord>) => {
    const created = await api.createSalary(data);
    setSalaries((prev) => [created, ...prev]);
    showToast(`Disbursed salary for ${created.employee_id}: $${Number(created.net_salary).toLocaleString()}`);
    api.getStats().then((s) => setStats(s)).catch(() => {});
  };

  // Leave Handlers
  const handleApplyLeave = async (data: {
    employee_id: string;
    leave_type: string;
    start_date: string;
    end_date: string;
    reason: string;
  }) => {
    const created = await api.applyLeave(data);
    setLeaves((prev) => [created, ...prev]);
    showToast(`Leave application submitted successfully for ${created.employee_id}`);
    api.getStats().then((s) => setStats(s)).catch(() => {});
  };

  const handleUpdateLeaveStatus = async (id: string, status: 'Approved' | 'Rejected') => {
    const updated = await api.updateLeaveStatus(id, status, currentUser.full_name || 'Admin');
    setLeaves((prev) => prev.map((l) => (l.id === id ? updated : l)));
    showToast(`Leave application #${id.slice(0, 6)} marked as ${status}`);
    api.getStats().then((s) => setStats(s)).catch(() => {});
  };

  // Performance Review Handlers
  const handleCreateReview = async (data: Partial<Performance>) => {
    const created = await api.createPerformance(data);
    setPerformance((prev) => [created, ...prev]);
    showToast(`Performance evaluation recorded for ${created.employee_id}`);
  };

  const handleDeleteReview = async (id: string) => {
    await api.deletePerformance(id);
    setPerformance((prev) => prev.filter((p) => p.id !== id));
    showToast('Appraisal record deleted');
  };

  const pendingLeavesCount = leaves.filter((l) => l.status === 'Pending').length;

  return (
    <div className="flex min-h-screen flex-col bg-slate-50 text-slate-900 antialiased dark:bg-slate-950 dark:text-slate-100 transition-colors">
      {/* Toast Banner */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 flex items-center gap-2 rounded-2xl bg-slate-900 px-4 py-3 text-xs font-semibold text-white shadow-2xl dark:bg-white dark:text-slate-950 border border-slate-700 animate-in fade-in slide-in-from-bottom-3 duration-300">
          <span className="h-2 w-2 rounded-full bg-indigo-500 animate-ping" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Top Navbar */}
      <Navbar
        currentUser={currentUser}
        onLogout={handleLogout}
        onRoleSwitch={handleRoleSwitch}
        darkMode={darkMode}
        onToggleDarkMode={() => setDarkMode(!darkMode)}
        onOpenDbModal={() => setActiveTab('database')}
        isSupabaseLive={isSupabaseLive}
      />

      <div className="flex flex-1 overflow-hidden">
        {/* Responsive Sidebar */}
        <Sidebar
          activeTab={activeTab}
          onSelectTab={(tab) => {
            setActiveTab(tab);
            setMobileSidebarOpen(false);
          }}
          userRole={currentUser.role}
          mobileOpen={mobileSidebarOpen}
          onToggleMobile={() => setMobileSidebarOpen(!mobileSidebarOpen)}
          pendingLeavesCount={pendingLeavesCount}
        />

        {/* Main Content Stage */}
        <main className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8">
          <div className="mx-auto max-w-7xl">
            {activeTab === 'dashboard' && (
              <DashboardView
                stats={stats}
                loading={loading}
                onNavigate={(tab) => setActiveTab(tab)}
                userRole={currentUser.role}
                onRefresh={loadAllData}
              />
            )}

            {activeTab === 'employees' && (
              <EmployeesView
                employees={employees}
                departments={departments}
                userRole={currentUser.role}
                onSaveEmployee={handleSaveEmployee}
                onDeleteEmployee={handleDeleteEmployee}
              />
            )}

            {activeTab === 'departments' && (
              <DepartmentsView
                departments={departments}
                employees={employees}
                userRole={currentUser.role}
                onSaveDepartment={handleSaveDepartment}
                onDeleteDepartment={handleDeleteDepartment}
              />
            )}

            {activeTab === 'attendance' && (
              <AttendanceView
                attendance={attendance}
                employees={employees}
                userRole={currentUser.role}
                onMarkAttendance={handleMarkAttendance}
              />
            )}

            {activeTab === 'salaries' && (
              <SalaryView
                salaries={salaries}
                employees={employees}
                userRole={currentUser.role}
                onCreateSalary={handleCreateSalary}
              />
            )}

            {activeTab === 'leaves' && (
              <LeavesView
                leaves={leaves}
                employees={employees}
                userRole={currentUser.role}
                onApplyLeave={handleApplyLeave}
                onUpdateStatus={handleUpdateLeaveStatus}
              />
            )}

            {activeTab === 'performance' && (
              <PerformanceView
                performance={performance}
                employees={employees}
                userRole={currentUser.role}
                onCreateReview={handleCreateReview}
                onDeleteReview={handleDeleteReview}
              />
            )}

            {activeTab === 'reports' && (
              <ReportsView
                employees={employees}
                departments={departments}
                attendance={attendance}
                leaves={leaves}
                salaries={salaries}
              />
            )}

            {activeTab === 'database' && (
              <DatabaseView
                isSupabaseLive={isSupabaseLive}
                counts={{
                  employees: employees.length,
                  departments: departments.length,
                  attendance: attendance.length,
                  salaries: salaries.length,
                  leaves: leaves.length,
                  performance: performance.length,
                }}
                onRefresh={loadAllData}
              />
            )}
          </div>
        </main>
      </div>

      {/* Authentication Modal */}
      <AuthModal
        isOpen={authModalOpen}
        onClose={() => setAuthModalOpen(false)}
        onLoginSuccess={handleLoginSuccess}
      />
    </div>
  );
}
