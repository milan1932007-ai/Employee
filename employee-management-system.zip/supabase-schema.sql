-- ==========================================================
-- EMPLOYEE MANAGEMENT SYSTEM (EMS) - SUPABASE / POSTGRESQL DDL
-- Tables: employees, departments, attendance, leaves, salaries, performance, users
-- ==========================================================

-- Enable UUID extension if needed
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- 1. DEPARTMENTS TABLE
CREATE TABLE IF NOT EXISTS departments (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    department_name VARCHAR(100) NOT NULL UNIQUE,
    department_head VARCHAR(150) NOT NULL,
    description TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 2. EMPLOYEES TABLE
CREATE TABLE IF NOT EXISTS employees (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    employee_id VARCHAR(50) NOT NULL UNIQUE,
    full_name VARCHAR(150) NOT NULL,
    gender VARCHAR(20) CHECK (gender IN ('Male', 'Female', 'Other')),
    dob DATE NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    phone VARCHAR(50) NOT NULL,
    address TEXT,
    department_id UUID REFERENCES departments(id) ON DELETE SET NULL,
    designation VARCHAR(100) NOT NULL,
    joining_date DATE NOT NULL DEFAULT CURRENT_DATE,
    salary NUMERIC(12, 2) NOT NULL DEFAULT 0.00,
    photo_url TEXT,
    status VARCHAR(30) DEFAULT 'Active' CHECK (status IN ('Active', 'On Leave', 'Terminated')),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 3. ATTENDANCE TABLE
CREATE TABLE IF NOT EXISTS attendance (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    employee_id VARCHAR(50) NOT NULL REFERENCES employees(employee_id) ON DELETE CASCADE,
    date DATE NOT NULL,
    status VARCHAR(20) NOT NULL CHECK (status IN ('Present', 'Absent', 'Half Day', 'On Leave')),
    check_in TIME,
    check_out TIME,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    CONSTRAINT unique_employee_daily_attendance UNIQUE (employee_id, date)
);

-- 4. LEAVES TABLE
CREATE TABLE IF NOT EXISTS leaves (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    employee_id VARCHAR(50) NOT NULL REFERENCES employees(employee_id) ON DELETE CASCADE,
    leave_type VARCHAR(50) NOT NULL CHECK (leave_type IN ('Casual', 'Sick', 'Paid', 'Maternity/Paternity', 'Unpaid')),
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    days_count INT NOT NULL DEFAULT 1,
    reason TEXT NOT NULL,
    status VARCHAR(30) NOT NULL DEFAULT 'Pending' CHECK (status IN ('Pending', 'Approved', 'Rejected')),
    approved_by VARCHAR(150),
    applied_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 5. SALARIES TABLE
CREATE TABLE IF NOT EXISTS salaries (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    employee_id VARCHAR(50) NOT NULL REFERENCES employees(employee_id) ON DELETE CASCADE,
    basic_salary NUMERIC(12, 2) NOT NULL DEFAULT 0.00,
    allowances NUMERIC(12, 2) NOT NULL DEFAULT 0.00,
    deductions NUMERIC(12, 2) NOT NULL DEFAULT 0.00,
    net_salary NUMERIC(12, 2) GENERATED ALWAYS AS (basic_salary + allowances - deductions) STORED,
    payment_date DATE NOT NULL,
    month_year VARCHAR(30) NOT NULL,
    payment_status VARCHAR(30) NOT NULL DEFAULT 'Paid' CHECK (payment_status IN ('Paid', 'Pending')),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 6. PERFORMANCE TABLE
CREATE TABLE IF NOT EXISTS performance (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    employee_id VARCHAR(50) NOT NULL REFERENCES employees(employee_id) ON DELETE CASCADE,
    rating INT NOT NULL CHECK (rating >= 1 AND rating <= 5),
    achievements TEXT,
    feedback TEXT NOT NULL,
    review_date DATE NOT NULL DEFAULT CURRENT_DATE,
    reviewer_name VARCHAR(150),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 7. USERS & ROLES TABLE (For Auth and RBAC)
CREATE TABLE IF NOT EXISTS users (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    email VARCHAR(150) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    full_name VARCHAR(150) NOT NULL,
    role VARCHAR(50) NOT NULL CHECK (role IN ('Admin', 'HR Manager', 'Employee')),
    employee_id VARCHAR(50) REFERENCES employees(employee_id) ON DELETE SET NULL,
    avatar TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- INDEXES FOR OPTIMAL QUERY PERFORMANCE
CREATE INDEX IF NOT EXISTS idx_employees_department ON employees(department_id);
CREATE INDEX IF NOT EXISTS idx_attendance_date ON attendance(date);
CREATE INDEX IF NOT EXISTS idx_attendance_employee ON attendance(employee_id);
CREATE INDEX IF NOT EXISTS idx_leaves_employee ON leaves(employee_id);
CREATE INDEX IF NOT EXISTS idx_salaries_employee ON salaries(employee_id);
CREATE INDEX IF NOT EXISTS idx_salaries_month ON salaries(month_year);

-- ==========================================================
-- ROW LEVEL SECURITY (RLS) POLICIES EXAMPLE (Supabase)
-- ==========================================================
ALTER TABLE departments ENABLE ROW LEVEL SECURITY;
ALTER TABLE employees ENABLE ROW LEVEL SECURITY;
ALTER TABLE attendance ENABLE ROW LEVEL SECURITY;
ALTER TABLE leaves ENABLE ROW LEVEL SECURITY;
ALTER TABLE salaries ENABLE ROW LEVEL SECURITY;
ALTER TABLE performance ENABLE ROW LEVEL SECURITY;

-- Allow read access to authenticated users
CREATE POLICY "Allow read access to authenticated users" ON departments FOR SELECT TO authenticated USING (true);
CREATE POLICY "Allow read access to authenticated users" ON employees FOR SELECT TO authenticated USING (true);
CREATE POLICY "Allow read access to authenticated users" ON attendance FOR SELECT TO authenticated USING (true);
CREATE POLICY "Allow read access to authenticated users" ON leaves FOR SELECT TO authenticated USING (true);
CREATE POLICY "Allow read access to authenticated users" ON salaries FOR SELECT TO authenticated USING (true);
CREATE POLICY "Allow read access to authenticated users" ON performance FOR SELECT TO authenticated USING (true);

-- Allow full access to service_role or admin users
CREATE POLICY "Full access to service role" ON departments FOR ALL TO service_role USING (true);
CREATE POLICY "Full access to service role" ON employees FOR ALL TO service_role USING (true);
CREATE POLICY "Full access to service role" ON attendance FOR ALL TO service_role USING (true);
CREATE POLICY "Full access to service role" ON leaves FOR ALL TO service_role USING (true);
CREATE POLICY "Full access to service role" ON salaries FOR ALL TO service_role USING (true);
CREATE POLICY "Full access to service role" ON performance FOR ALL TO service_role USING (true);

-- ==========================================================
-- SAMPLE SEED DATA
-- ==========================================================

INSERT INTO departments (id, department_name, department_head, description) VALUES
('11111111-1111-1111-1111-111111111111', 'Engineering', 'Sarah Jenkins', 'Software development, infrastructure, and technical operations'),
('22222222-2222-2222-2222-222222222222', 'Human Resources', 'Michael Chang', 'Talent acquisition, employee welfare, and compensation'),
('33333333-3333-3333-3333-333333333333', 'Product & Design', 'Elena Rostova', 'Product strategy, UI/UX research, and product delivery'),
('44444444-4444-4444-4444-444444444444', 'Marketing & Sales', 'David Miller', 'Growth marketing, brand positioning, and enterprise sales'),
('55555555-5555-5555-5555-555555555555', 'Finance & Legal', 'Priya Sharma', 'Financial planning, accounting, compliance, and auditing')
ON CONFLICT (department_name) DO NOTHING;

INSERT INTO employees (employee_id, full_name, gender, dob, email, phone, address, department_id, designation, joining_date, salary, photo_url, status) VALUES
('EMP001', 'Alexander Hayes', 'Male', '1990-05-14', 'alexander.hayes@company.com', '+1 (555) 234-5678', '742 Evergreen Terrace, Seattle, WA', '11111111-1111-1111-1111-111111111111', 'Lead Software Architect', '2021-03-15', 115000.00, 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&h=200&fit=crop&crop=faces', 'Active'),
('EMP002', 'Emma Watson', 'Female', '1993-08-22', 'emma.watson@company.com', '+1 (555) 876-5432', '120 Market St, San Francisco, CA', '33333333-3333-3333-3333-333333333333', 'Senior UX Designer', '2022-01-10', 95000.00, 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=200&h=200&fit=crop&crop=faces', 'Active'),
('EMP003', 'Marcus Vance', 'Male', '1988-11-03', 'marcus.vance@company.com', '+1 (555) 432-1098', '45 Ocean Drive, Austin, TX', '11111111-1111-1111-1111-111111111111', 'DevOps & Cloud Engineer', '2020-07-01', 105000.00, 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&h=200&fit=crop&crop=faces', 'Active'),
('EMP004', 'Sophia Rivera', 'Female', '1995-02-18', 'sophia.rivera@company.com', '+1 (555) 345-6789', '88 Beacon Hill, Boston, MA', '22222222-2222-2222-2222-222222222222', 'HR Business Partner', '2023-04-12', 78000.00, 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=200&h=200&fit=crop&crop=faces', 'Active'),
('EMP005', 'Liam Bennett', 'Male', '1992-09-30', 'liam.bennett@company.com', '+1 (555) 654-9870', '500 Grand Ave, Chicago, IL', '44444444-4444-4444-4444-444444444444', 'Enterprise Account Director', '2022-06-20', 110000.00, 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=200&h=200&fit=crop&crop=faces', 'Active'),
('EMP006', 'Aaliyah Patel', 'Female', '1994-07-14', 'aaliyah.patel@company.com', '+1 (555) 789-0123', '210 River Walk, New York, NY', '55555555-5555-5555-5555-555555555555', 'Senior Financial Analyst', '2021-10-05', 92000.00, 'https://images.unsplash.com/photo-1580489944761-15a19d654956?w=200&h=200&fit=crop&crop=faces', 'Active')
ON CONFLICT (employee_id) DO NOTHING;
